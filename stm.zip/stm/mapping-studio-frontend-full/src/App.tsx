import React from 'react'
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom'
import MappingPage from './pages/MappingPage'
import PreviewDVHPage from './pages/PreviewDVHPage'
import ExecutionPage from './pages/ExecutionPage'
import ResultPage from './pages/ResultPage'
import SettingsPage from './pages/SettingsPage'

function useLastMapping(){
  try{
    const lm = JSON.parse(localStorage.getItem('lastMapping')||'{}')
    return { id: lm.id, version: lm.version, title: lm.title }
  }catch{return {} as any}
}

function Tabs(){
  const {pathname} = useLocation()
  const last = useLastMapping()
  const Tab = ({to,children}:{to:string;children:any}) => (
    <Link to={to} className={`tab ${pathname===to?'active':''}`} style={{padding:'10px 12px', textDecoration:'none', borderBottom: pathname===to ? '2px solid gold':'2px solid transparent'}}>{children}</Link>
  )
  return (
    <div className="nav" style={{display:'flex',gap:12,alignItems:'center',height:48,borderBottom:'1px solid var(--border)'}}>
      <div style={{fontWeight:700, padding:'0 12px'}}>Mapping Studio v3.9.7</div>
      {last?.title && <div className="badge" title={`${last.id || ''}@${last.version || ''}`}>🗂️ {last.title}</div>}
      <Tab to="/">Mapping</Tab>
      <Tab to="/preview">Preview</Tab>
      <Tab to="/execution">Execution</Tab>
      <Tab to="/result">Result</Tab>
      <Tab to="/settings">Settings</Tab>
    </div>
  )
}

export default function App(){
  return (
    <BrowserRouter>
      <Tabs/>
      <Routes>
        <Route path="/" element={<MappingPage/>}/>
        <Route path="/preview" element={<PreviewDVHPage/>}/>
        <Route path="/execution" element={<ExecutionPage/>}/>
        <Route path="/result" element={<ResultPage/>}/>
        <Route path="/settings" element={<SettingsPage/>}/>
      </Routes>
    </BrowserRouter>
  )
}
