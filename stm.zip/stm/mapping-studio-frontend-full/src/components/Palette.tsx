import React from 'react'
type Item = { label:string, kind:string, type:'dataset'|'target'|'transform'|'join' }
const items: Item[] = [
  {label:'Hive', kind:'HIVE', type:'dataset'},
  {label:'Neo4j', kind:'NEO4J', type:'dataset'},
  {label:'Mongo', kind:'MONGO', type:'dataset'},
  {label:'Oracle', kind:'ORACLE', type:'dataset'},
  {label:'Files (CSV/JSON/Excel)', kind:'FILE', type:'dataset'},
  {label:'Elastic', kind:'ELASTIC', type:'dataset'},
  {label:'Kafka', kind:'KAFKA', type:'dataset'},
  {label:'API', kind:'API', type:'dataset'},
  {label:'GraphQL', kind:'GQL', type:'dataset'},
  {label:'Join', kind:'JOIN', type:'join'},
  {label:'Transform', kind:'PROC', type:'transform'},
  {label:'Output', kind:'OUTPUT', type:'target'},
]
export default function Palette(){
  const onDragStart=(e:React.DragEvent, it:Item)=>{
    e.dataTransfer.setData('application/x-node', JSON.stringify(it))
    e.dataTransfer.effectAllowed = 'copyMove'
  }
  return <div style={{display:'grid',gap:6}}>
    {items.map((it)=> (
      <div key={it.label} className="panel palette-item" draggable onDragStart={(e)=>onDragStart(e,it)}>
        <div style={{display:'flex', justifyContent:'space-between'}}>
          <span>{it.label}</span>
          <span className="badge">{it.kind}</span>
        </div>
      </div>
    ))}
  </div>
}
