import React, {useRef} from 'react'
export default function AttributeGrid({rows,setRows}:{rows:any[], setRows:any}){
  const fileRef = useRef<HTMLInputElement>(null)
  const add = ()=> setRows([...rows, {sourceAttr:'', targetAttr:'', expression:'', filter:'', alias:'', dtype:''}])
  const removeLast = ()=> setRows(rows.slice(0,-1))
  const set = (i:number, k:string, v:string)=> setRows(rows.map((r,ri)=> ri===i? {...r,[k]:v}:r))

  const onUpload = async(e:any)=>{
    const f = e.target.files?.[0]; if(!f) return;
    const text = await f.text(); // simple CSV parse
    const lines = text.split(/\r?\n/).filter(Boolean)
    const hdr = lines[0].split(',').map(s=>s.trim().toLowerCase())
    const idx = (name:string)=> hdr.findIndex(h=> [name, name.replace(/_/g,'')].includes(h))
    const out:any[] = []
    for (let i=1;i<lines.length;i++){
      const c = lines[i].split(',')
      out.push({
        sourceAttr: c[idx('source')]==null? '': c[idx('source')],
        targetAttr: c[idx('target')]==null? '': c[idx('target')],
        expression: c[idx('expression')]==null? '': c[idx('expression')],
        filter: c[idx('filter')]==null? '': c[idx('filter')],
        alias: c[idx('alias')]==null? '': c[idx('alias')],
        dtype: c[idx('dtype')]==null? '': c[idx('dtype')],
      })
    }
    setRows(out)
  }

  return (<div>
    <div style={{display:'flex', gap:6, marginBottom:8}}>
      <button onClick={add}>Add Row</button>
      <button onClick={removeLast}>Remove Last</button>
      <input type="file" ref={fileRef} onChange={onUpload} />
    </div>
    <div className="panel" style={{padding:0, overflow:'hidden'}}>
      <table style={{width:'100%'}}>
        <thead><tr>
          <th>Source</th><th>Target</th><th>Expression</th><th>Filter</th><th>Alias</th><th>DType</th>
        </tr></thead>
        <tbody>
          {rows.map((r,i)=> (
            <tr key={i}>
              {['sourceAttr','targetAttr','expression','filter','alias','dtype'].map(k=> (
                <td key={k}><input value={r[k]||''} onChange={e=>set(i,k,e.target.value)} /></td>
              ))}
            </tr>
          ))}
          {rows.length===0 && <tr><td colSpan={6} style={{padding:8, opacity:.7}}>No attributes yet</td></tr>}
        </tbody>
      </table>
    </div>
  </div>)
}
