import React from 'react'
export default function TogglePanel({title, visible, onToggle, children}:{title:string;visible:boolean;onToggle:()=>void;children:any}){
  return (<div className="panel" style={{marginBottom:12}}>
    <div className="toggle">
      <strong>{title}</strong>
      <button className="icon-btn" onClick={onToggle} title={visible?'Hide':'Show'} aria-label={visible?'Hide section':'Show section'}>
        {visible ? '👁️' : '🙈'}
      </button>
    </div>
    {visible && children}
  </div>)
}
