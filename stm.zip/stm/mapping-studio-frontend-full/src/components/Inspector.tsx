import React from 'react'
import type { Node, Edge } from 'react-flow-renderer'
import { listProfiles, getProfile } from '../profiles'

export default function Inspector({selectedNode,setSelectedNode,selectedEdge,setEdges,setNodes}:{selectedNode:Node|null;setSelectedNode:(n:Node|null)=>void;selectedEdge:Edge|null;setEdges:React.Dispatch<React.SetStateAction<Edge[]>>;setNodes:React.Dispatch<React.SetStateAction<Node[]>>;}){
  if(!selectedNode && !selectedEdge) return <div style={{opacity:.7}}>Select a node or edge</div>

  const removeSelectedNode=()=>{ if(!selectedNode) return; const id=selectedNode.id; setEdges(eds=> eds.filter(e=> e.source!==id && e.target!==id)); setNodes(nds=> nds.filter(n=> n.id!==id)); setSelectedNode(null) }
  const removeSelectedEdge=()=>{ if(!selectedEdge) return; const id=selectedEdge.id; setEdges(eds=> eds.filter(e=> e.id!==id)); }

  const profiles = listProfiles();
  const chosen = selectedNode?.data?.profileId ? getProfile(selectedNode?.data?.profileId) : undefined;

  return (<div style={{display:'grid',gap:8}}>
    {selectedNode && (<>
      <div><strong>Name</strong></div>
      <input defaultValue={(selectedNode.data as any)?.name||''}
        onBlur={(e)=> setNodes(nds=> nds.map(n=> n.id===selectedNode.id?({...n,data:{...n.data,name:e.target.value}}):n))}/>

      <div><strong>Connection Profile</strong></div>
      <select value={(selectedNode.data as any)?.profileId || ''}
        onChange={(e)=> setNodes(nds=> nds.map(n=> n.id===selectedNode.id?({...n,data:{...n.data,profileId:e.target.value,profileName:(profiles.find(p=>p.id===e.target.value)?.name||'')}}):n))}>
        <option value=''>— none —</option>
        {profiles.map(p=> (<option key={p.id} value={p.id}>{p.name} ({p.kind})</option>))}
      </select>
      {chosen && (<div className='panel' style={{fontSize:12,opacity:.85}}><div><strong>{chosen.name}</strong> · {chosen.kind}</div><div>Params: {Object.keys(chosen.params||{}).length}</div></div>)}

      <button onClick={removeSelectedNode}>Remove Node</button>
    </>)}

    {selectedEdge && (<>
      <div><strong>Edge label</strong></div>
      <input defaultValue={(selectedEdge as any).label||''}
        onBlur={(e)=> setEdges(eds=> eds.map(edge=> edge.id===selectedEdge.id?({...edge,label:e.target.value}):edge))}/>
      <button onClick={removeSelectedEdge}>Remove Edge</button>
    </>)}
  </div>)
}
