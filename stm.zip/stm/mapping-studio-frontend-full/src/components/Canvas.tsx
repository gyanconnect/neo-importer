import React, {useCallback, useRef, useState} from 'react'
import ReactFlow, {Background, Controls, MiniMap, addEdge, useReactFlow, ReactFlowProvider} from 'react-flow-renderer'
import DatasetNode from './nodes/DatasetNode'
import TransformNode from './nodes/TransformNode'
import JoinNode from './nodes/JoinNode'
import TargetNode from './nodes/TargetNode'

const nodeTypes = { dataset: DatasetNode, transform: TransformNode, join: JoinNode, target: TargetNode }

type Props = {
  nodes:any[]; edges:any[]; setEdges:Function;
  onSelect:(node:any, edge:any)=>void;
  onNodesChange:any; onEdgesChange:any;
  onCreateNode:(type:string,name:string,pos:{x:number;y:number})=>void
}

function CanvasInner({nodes, edges, setEdges, onSelect, onNodesChange, onEdgesChange, onCreateNode}:Props){
  const { project } = useReactFlow()
  const wrapperRef = useRef<HTMLDivElement>(null)
  const [isDropping, setDropping] = useState(false)

  const onConnect = useCallback((params:any)=> setEdges((eds:any)=> addEdge({ ...params, type:'smoothstep', animated:true, style:{ stroke:'#d1a500' } }, eds)), [])
  const onNodeClick = (_:any, node:any)=> onSelect(node, null)
  const onEdgeClick = (_:any, edge:any)=> onSelect(null, edge)

  const onDragOver = (e:React.DragEvent)=>{ e.preventDefault(); e.dataTransfer.dropEffect='copy'; setDropping(true) }
  const onDragLeave = ()=> setDropping(false)
  const onDrop = (e:React.DragEvent)=>{
    e.preventDefault(); setDropping(false)
    const raw = e.dataTransfer.getData('application/x-node'); if(!raw) return;
    const it = JSON.parse(raw)
    const bounds = wrapperRef.current?.getBoundingClientRect()
    const pos = project({ x: e.clientX - (bounds?.left||0), y: e.clientY - (bounds?.top||0) })
    const name = it.label
    const type = it.type
    onCreateNode(type, name, pos)
  }

  return (<div style={{height:'calc(100vh - 48px)'}} id="rf-canvas-root"
              ref={wrapperRef}
              className={isDropping?'dropping':''}
              onDrop={onDrop} onDragOver={onDragOver} onDragLeave={onDragLeave}>
    <ReactFlow nodes={nodes} edges={edges} nodeTypes={nodeTypes}
      onConnect={onConnect} onNodesChange={onNodesChange} onEdgesChange={onEdgesChange}
      onNodeClick={onNodeClick} onEdgeClick={onEdgeClick} fitView>
      <Background />
      <MiniMap />
      <Controls />
    </ReactFlow>
  </div>)
}

export default function Canvas(props:Props){
  return (
    <ReactFlowProvider>
      <CanvasInner {...props} />
    </ReactFlowProvider>
  )
}
