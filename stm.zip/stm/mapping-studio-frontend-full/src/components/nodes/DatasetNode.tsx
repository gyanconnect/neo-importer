import React from 'react'
import { Handle, Position } from 'react-flow-renderer'
export default ({data}:any)=> (
  <div className='panel' style={{minWidth:220, position:'relative'}}>
    <div style={{fontWeight:700}}>{data.name||'Dataset'}</div>
    <div className='badge'>{data.columns||'—'} columns</div>
    {data.profileName && <div style={{position:'absolute', right:8, bottom:8, fontSize:11, opacity:.8, border:'1px solid var(--border)', padding:'2px 6px', borderRadius:6}}>{data.profileName}</div>}
    <Handle type="source" position={Position.Right} id="out" />
    <Handle type="target" position={Position.Left} id="in" />
  </div>
)