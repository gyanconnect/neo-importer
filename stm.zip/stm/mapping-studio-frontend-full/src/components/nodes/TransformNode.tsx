import React from 'react'
import { Handle, Position } from 'react-flow-renderer'
export default ({data}:any)=> (
  <div className='panel' style={{minWidth:260, position:'relative'}}>
    <div style={{fontWeight:700}}>{data.name||'Transform'}</div>
    <div style={{opacity:.7}}>{data.subtitle||''}</div>
    <Handle type="target" position={Position.Left} id="in" />
    <Handle type="source" position={Position.Right} id="out" />
  </div>
)