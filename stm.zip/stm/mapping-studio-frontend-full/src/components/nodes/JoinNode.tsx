import React from 'react'
import { Handle, Position } from 'react-flow-renderer'
export default ({data}:any)=> (
  <div className='panel' style={{minWidth:240,borderColor:'#d1a500'}}>
    <div style={{fontWeight:700}}>🔗 {data.name||'Join'}</div>
    <div style={{fontSize:12,opacity:.8}}>INNER • L_key • R_key</div>
    <Handle type="target" position={Position.Left} id="left" />
    <Handle type="target" position={Position.Top} id="right" />
    <Handle type="source" position={Position.Right} id="out" />
  </div>
)