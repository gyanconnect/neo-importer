import React from 'react'
import { Handle, Position } from 'react-flow-renderer'
export default ({data}:any)=> (
  <div className='panel' style={{minWidth:220}}>
    <div style={{fontWeight:700}}>📦 {data.name||'Target'}</div>
    <div className='badge'>Dataset</div>
    <Handle type="target" position={Position.Left} id="in" />
  </div>
)