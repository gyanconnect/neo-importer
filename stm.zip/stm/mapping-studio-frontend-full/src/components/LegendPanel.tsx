import React from 'react'
export default ()=> <div className="panel" style={{marginTop:12, fontSize:12, opacity:.8}}>Edges: gold, curved, animated</div>
