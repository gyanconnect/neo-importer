export async function gql<T=any>(query: string, variables?: any): Promise<T> {
  const base = localStorage.getItem('apiBase') || 'http://localhost:8000'
  const res = await fetch(`${base}/graphql`, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ query, variables }) })
  const json = await res.json()
  if (json.errors) throw new Error(json.errors.map((e:any)=>e.message).join('\n'))
  return json.data as T
}