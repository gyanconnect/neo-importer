export type Profile = {
  id: string;
  name: string;
  kind: 'HIVE'|'NEO4J'|'MONGO'|'ORACLE'|'FILE'|'KAFKA'|'API'|'GQL'|'ELASTIC';
  params: Record<string,string>;
};
const KEY = 'connProfiles';
export function listProfiles(): Profile[] { try{ return JSON.parse(localStorage.getItem(KEY)||'[]'); } catch { return [] } }
export function saveProfiles(items: Profile[]) { localStorage.setItem(KEY, JSON.stringify(items)); }
export function upsertProfile(p: Profile) { const items=listProfiles(); const i=items.findIndex(x=>x.id===p.id); if(i>=0) items[i]=p; else items.push(p); saveProfiles(items) }
export function getProfile(id?:string|null){ return listProfiles().find(p=>p.id===id) }
export const REQUIRED_BY_KIND: Record<Profile['kind'], string[]> = {
  HIVE:['host','port','database'], NEO4J:['url','user','password'], MONGO:['uri','database'],
  ORACLE:['dsn','user','password'], FILE:['basePath'], KAFKA:['brokers','topic'], API:['baseUrl'], GQL:['endpoint'], ELASTIC:['node','index'],
};
