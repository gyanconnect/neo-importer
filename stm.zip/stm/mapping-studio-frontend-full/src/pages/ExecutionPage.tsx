import React, { useState, useEffect } from 'react'
import { gql } from '../api/client'

export default function ExecutionPage(){
  const last = JSON.parse(localStorage.getItem('lastMapping')||'{}')
  const [id,setId] = useState(last.id || 'customer-etl')
  const [version,setVersion] = useState(last.version || 'v1')
  const [title,setTitle] = useState<string>(last.title || '')
  const [jobId,setJobId] = useState<string|undefined>(localStorage.getItem('lastJobId')||undefined)
  const [output,setOutput] = useState('')
  const [error,setError] = useState<string|undefined>()

  useEffect(()=>{
    (async()=>{
      try{
        const data = await gql<any>(`query($id:String!,$v:String!){ mapping(id:$id,version:$v){ title } }`, {id, v:version})
        if(data?.mapping?.title){ setTitle(data.mapping.title); localStorage.setItem('lastMapping', JSON.stringify({id, version, title:data.mapping.title, at: Date.now()})) }
      }catch{}
    })()
  },[id,version])

  const call = async (q:string, vars:any)=>{
    setError(undefined)
    try{
      const res = await gql<any>(q, vars)
      setOutput(JSON.stringify(res,null,2))
      if(res?.exec_run){ setJobId(res.exec_run); localStorage.setItem('lastJobId', res.exec_run) }
      return res
    }catch(e:any){ setError(e.message||String(e)); throw e }
  }

  const validate = ()=> call(`query($id:String!,$v:String!){ exec_validate(id:$id,version:$v) }`, {id, v:version})
  const plan = ()=> call(`query($id:String!,$v:String!){ exec_plan(id:$id,version:$v) }`, {id, v:version})
  const preview = ()=> call(`query($id:String!,$v:String!){ exec_preview(id:$id,version:$v){ columns sampleRows } }`, {id, v:version})
  const run = ()=> call(`mutation($id:String!,$v:String!){ exec_run(id:$id,version:$v) }`, {id, v:version})
  const status = ()=> call(`query($job:String!){ exec_status(jobId:$job) }`, {job: jobId})
  const logs = ()=> call(`query($job:String!){ exec_logs(jobId:$job) }`, {job: jobId})
  const result = ()=> call(`query($job:String!){ exec_result(jobId:$job){ columns rows } }`, {job: jobId})

  return <div style={{padding:12, display:'grid', gap:12}}>
    <div className="panel" style={{display:'flex', gap:12, alignItems:'center'}}>
      <strong>Execution {title ? `— ${title}` : ''}</strong>
      <label>Mapping ID <input value={id} onChange={e=>setId(e.target.value)} /></label>
      <label>Version <input value={version} onChange={e=>setVersion(e.target.value)} /></label>
      <button onClick={validate}>/exec/validate</button>
      <button onClick={plan}>/plan</button>
      <button onClick={preview}>/preview</button>
      <button onClick={run}>/run</button>
      <button onClick={status} disabled={!jobId}>/status</button>
      <button onClick={logs} disabled={!jobId}>/logs</button>
      <button onClick={result} disabled={!jobId}>/result</button>
      {jobId && <span className="badge">job: {jobId}</span>}
    </div>
    {error && <div className="panel" style={{borderColor:'tomato', color:'tomato'}}>Error: {error}</div>}
    <div className="panel" style={{whiteSpace:'pre-wrap', fontFamily:'ui-monospace, SFMono-Regular, Menlo, Consolas', fontSize:12}}>
      {output || 'Run a step to see output.'}
    </div>
  </div>
}
