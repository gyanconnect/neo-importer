import React, {useEffect, useMemo, useState} from 'react'
import { useLocation } from 'react-router-dom'
import ReactFlow, {Background, Controls, MiniMap} from 'react-flow-renderer'
import { gql } from '../api/client'

type Graph = { nodes: {id:string,label:string,caption:string}[], edges:{id:string,source:string,target:string,type:string,attrs:any}[] }

function useQuery(){
  const {search} = useLocation()
  return useMemo(()=> new URLSearchParams(search), [search])
}

export default function PreviewDVHPage(){
  const qs = useQuery()
  const last = JSON.parse(localStorage.getItem('lastMapping')||'{}')
  const [id,setId] = useState(qs.get('id') || last.id || 'flight-alerts')
  const [version,setVersion] = useState(qs.get('v') || last.version || 'v1')
  const [relType,setRelType] = useState(qs.get('rel') || '')
  const [limit,setLimit] = useState(parseInt(qs.get('n')||'50'))
  const [title,setTitle] = useState<string>(qs.get('title') || last.title || '')

  const [graph,setGraph] = useState<Graph>({nodes:[],edges:[]})
  const [srcRows,setSrcRows] = useState<any[]>([])
  const [tgtRows,setTgtRows] = useState<any[]>([])
  const [info,setInfo] = useState({sourceLabel:'',targetLabel:'',relType:''})
  const [loading,setLoading]=useState(false); const [error,setError]=useState<string|undefined>()

  const fetchTitle = async()=>{
    try{
      const data = await gql<any>(`query($id:String!,$v:String!){ mapping(id:$id,version:$v){ title } }`, {id, v:version})
      const t = data?.mapping?.title || ''
      setTitle(t)
      if (t){
        localStorage.setItem('lastMapping', JSON.stringify({id, version, title:t, at: Date.now()}))
      }
    }catch{}
  }

  const fetchByMapping = async()=>{
    setLoading(true); setError(undefined);
    try{
      const q = `query($id:String!,$v:String!,$rel:String,$n:Int){
        preview_by_mapping(id:$id, version:$v, relType:$rel, limit:$n){
          sourceLabel targetLabel relType
          graph{ nodes{ id label caption } edges{ id source target type attrs } }
          sourceSamples{ props } targetSamples{ props }
        }
      }`
      const data = await gql<any>(q, {id, v:version, rel: relType || null, n: limit})
      setGraph(data.preview_by_mapping.graph)
      setSrcRows(data.preview_by_mapping.sourceSamples.map((x:any)=>x.props))
      setTgtRows(data.preview_by_mapping.targetSamples.map((x:any)=>x.props))
      setInfo({sourceLabel:data.preview_by_mapping.sourceLabel, targetLabel:data.preview_by_mapping.targetLabel, relType:data.preview_by_mapping.relType})
    }catch(e:any){ setError(e.message||String(e)) } finally{ setLoading(false) }
  }

  useEffect(()=>{ fetchTitle(); fetchByMapping() },[id,version,relType,limit, qs.toString()])

  const nodes = graph.nodes.map((n:any, i:number)=> ({
    id:n.id, data:{label:`${n.label}\n${n.caption}`}, position:{x:120+(i%3)*260, y:120+Math.floor(i/3)*140}
  }))
  const edges = graph.edges.map((e:any)=> ({id:e.id, source:e.source, target:e.target, label:e.type, type:'smoothstep', animated:true}))

  const renderTable=(rows:any[], title:string)=>(
    <div style={{flex:1,minWidth:320}}>
      <div style={{fontWeight:700, margin:'8px 0'}}>{title}</div>
      <div style={{border:'1px solid var(--border)', borderRadius:8, overflow:'hidden'}}>
        <table style={{width:'100%', fontSize:13}}>
          <thead style={{background:'var(--panel)'}}><tr><th style={{textAlign:'left',padding:8}}>Property</th><th style={{textAlign:'left'}}>Value</th></tr></thead>
          <tbody>
            {rows.length===0 && <tr><td colSpan={2} style={{padding:8,opacity:.7}}>No rows</td></tr>}
            {rows.map((r:any,ri:number)=> Object.keys(r).slice(0,8).map((k,ki)=> (
              <tr key={ri+'-'+ki}><td style={{padding:6,borderTop:'1px solid var(--border)'}}>{k}</td><td style={{padding:6,borderTop:'1px solid var(--border)'}}>{String(r[k])}</td></tr>
            )))}
          </tbody>
        </table>
      </div>
    </div>
  )

  return (
    <div style={{height:'calc(100vh - 48px)'}}>
      <div className="preview-toolbar">
        <strong>Preview {title ? `— ${title}` : ''}</strong>
        <label>Mapping ID <input value={id} onChange={e=>setId(e.target.value)} /></label>
        <label>Version <input value={version} onChange={e=>setVersion(e.target.value)} /></label>
        <label>Rel <input value={relType} onChange={e=>setRelType(e.target.value)} placeholder="BidFor" /></label>
        <label>Limit <input type="number" value={limit} onChange={e=>setLimit(parseInt(e.target.value||'50'))} style={{width:80}}/></label>
        <button onClick={fetchByMapping} disabled={loading}>{loading?'Loading…':'Fetch from Mapping'}</button>
        {error && <div style={{color:'tomato', marginLeft:12}}>Error: {error}</div>}
        <div style={{opacity:.8, marginLeft:12}}>Detected: <b>{info.sourceLabel}</b> —[{info.relType}]→ <b>{info.targetLabel}</b></div>
      </div>
      <div style={{display:'grid', gridTemplateColumns:'1fr 420px', height:'calc(100% - 42px)'}}>
        <div>
          <ReactFlow nodes={nodes as any} edges={edges as any} fitView>
            <Background />
            <MiniMap />
            <Controls />
          </ReactFlow>
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:12, padding:12, overflow:'auto', borderLeft:'1px solid var(--border)'}}>
          {renderTable(srcRows, 'Source Samples')}
          {renderTable(tgtRows, 'Target Samples')}
        </div>
      </div>
    </div>
  )
}
