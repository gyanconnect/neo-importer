import { useMemo, useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import Canvas from '../components/Canvas'
import TogglePanel from '../components/TogglePanel'
import Inspector from '../components/Inspector'
import AttributeGrid from '../components/AttributeGrid'
import { gql } from '../api/client'
import { Node, Edge, applyNodeChanges, applyEdgeChanges } from 'react-flow-renderer'
import LegendPanel from '../components/LegendPanel'
import Palette from '../components/Palette'
import { getProfile, REQUIRED_BY_KIND } from '../profiles'

let idCounter=0; const nid=(p:string)=>`${p}_${++idCounter}`

export default function MappingPage(){
  const nav = useNavigate()
  const [mappingId,setMappingId]=useState('customer-etl')
  const [mappingTitle,setMappingTitle]=useState('Customer Mapping')   // <-- Mapping Name
  const [version,setVersion]=useState('v1')
  const [showConcepts,setShowConcepts]=useState(true)
  const [showInspector,setShowInspector]=useState(true)
  const [showAttributes,setShowAttributes]=useState(true)

  const [nodes,setNodes]=useState<Node[]>([
    {id:nid('dataset'), type:'dataset', position:{x:380,y:260}, data:{name:'Customer', kind:'FILE'}} as any,
    {id:nid('target'), type:'target', position:{x:800,y:260}, data:{name:'CustomerClean', kind:'OUTPUT'}} as any
  ])
  const [edges,setEdges]=useState<Edge[]>([])

  const onNodesChange=useCallback((changes:any)=> setNodes(nds=> applyNodeChanges(changes,nds)),[])
  const onEdgesChange=useCallback((changes:any)=> setEdges(eds=> applyEdgeChanges(changes,eds)),[])

  const onCreateNode=useCallback((type:string,name:string,pos:{x:number;y:number})=>{
    const data= type==='target'? {name} : {name,columns:'—'}
    setNodes(ns=> [...ns,{id:nid(type),type,position:pos,data}])
  },[])

  const [attrs,setAttrs]=useState<any[]>([])
  const [selectedNode,setSelectedNode]=useState<Node|null>(null)
  const [selectedEdge,setSelectedEdge]=useState<Edge|null>(null)

  const autoSourceTarget = useCallback(()=>{
    const indeg:Record<string,number>={}, outdeg:Record<string,number>={};
    nodes.forEach(n=>{indeg[n.id]=0; outdeg[n.id]=0});
    edges.forEach((e:any)=>{ outdeg[e.source]=(outdeg[e.source]||0)+1; indeg[e.target]=(indeg[e.target]||0)+1; });
    const sources = nodes.filter(n=> (outdeg[n.id]||0)>0 && (indeg[n.id]||0)===0);
    const targets = nodes.filter(n=> (indeg[n.id]||0)>0 && (outdeg[n.id]||0)===0);
    return { source: sources[0] || nodes[0], target: targets[0] || nodes[nodes.length-1] };
  }, [nodes, edges]);

  // Build GraphQL payload (note title: mappingTitle)
  const mappingPayload=useMemo(()=>{
    const {source: s, target: t} = autoSourceTarget();
    const attributes = attrs.map((a:any)=> ({
      sourceAttr: a.sourceAttr ?? a.source_attr ?? '',
      targetAttr: a.targetAttr ?? a.target_attr ?? '',
      expression: a.expression ?? '',
      filter: a.filter ?? '',
      alias: a.alias ?? '',
      dtype: a.dtype ?? '',
    }));
    return {
      id:mappingId,
      version,
      title:mappingTitle,                                           // <-- saved as title
      description:'{"meta_model_version":"mmv-1.0.0"}',
      status:'DRAFT',
      source: s ? { id:s.id, kind:(s.data as any)?.kind || 'FILE', name:(s.data as any)?.name || 'Customer' } : {id:'',kind:'FILE',name:''},
      target: t ? { id:t.id, kind:(t.data as any)?.kind || 'OUTPUT', name:(t.data as any)?.name || 'CustomerClean' } : {id:'',kind:'OUTPUT',name:''},
      attributes
    };
  },[mappingId,version,mappingTitle,attrs,nodes,edges,autoSourceTarget]);

  const uiPayload=useMemo(()=>({nodes:nodes.map(n=>({id:n.id,type:n.type,position:n.position,data:n.data})),edges:edges.map(e=>({id:e.id,source:e.source,target:e.target,label:e.label,data:(e as any).data}))}),[nodes,edges])

  const bumpVersion=()=>{ const m=/v(\d+)/.exec(version); const n=m?Number(m[1])+1:2; setVersion(`v${n}`) }
  const onSelect=(n:any,e:any)=>{ setSelectedNode(n); setSelectedEdge(e); if(e) setShowAttributes(true) }

  function validateProfiles(): string[] {
    const issues: string[] = [];
    nodes.forEach(n => {
      const pid = (n.data as any)?.profileId as string | undefined;
      const pname = (n.data as any)?.profileName || '(unnamed)';
      if (!pid) return; // optional
      const prof = getProfile(pid);
      if (!prof) { issues.push(`Node ${n.data?.name||n.id}: selected profile not found`); return; }
      const req = REQUIRED_BY_KIND[prof.kind] || [];
      const missing = req.filter(k => !prof.params || !String(prof.params[k]||'').trim());
      if (missing.length) issues.push(`Node ${n.data?.name||n.id}: profile "${pname}" (${prof.kind}) missing: ${missing.join(', ')}`);
    });
    return issues;
  }

  const doSave=async()=>{
    const errs = validateProfiles();
    if (errs.length){ alert('Fix connection profile settings before saving:\n\n' + errs.join('\n')); return false; }
    const q=`mutation($input: MappingInput!){ upsertMapping(input:$input) }`; 
    await gql(q,{input:mappingPayload}); 
    return true;
  }
  const pushLayout=async()=>{const q=`mutation($id:String!, $version:String!, $ui:JSON!){ setUi(id:$id, version:$version, ui:$ui) }`; await gql(q,{id:mappingId,version,ui:uiPayload}); }

  const save=async()=>{ const ok = await doSave(); if(ok) alert('Saved mapping'); }
  const saveThenPreview=async()=>{
    const ok = await doSave();
    if(!ok) return;
    try{ await pushLayout(); }catch{}
    localStorage.setItem('lastMapping', JSON.stringify({id:mappingId, version}))
    nav(`/preview?id=${encodeURIComponent(mappingId)}&v=${encodeURIComponent(version)}`)
  }
  const download=async()=>{ const zip={mapping:mappingPayload,ui:uiPayload,attributes:attrs}; const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([JSON.stringify(zip,null,2)],{type:'application/json'})); a.download=`bundle-${mappingId}-${version}.json`; a.click() }
  const clear=()=>{ setNodes([]); setEdges([]); setAttrs([]); setSelectedEdge(null); setSelectedNode(null); }

  return (<div className='content'>
    <div className='sidebar'>
      <TogglePanel title='Data Product Concepts' visible={showConcepts} onToggle={()=>setShowConcepts(!showConcepts)}><Palette/></TogglePanel>
      <div className='panel' style={{display:'grid',gap:8, marginTop:12}}>
        <label><div>Mapping ID</div><input value={mappingId} onChange={(e)=>setMappingId(e.target.value)}/></label>
        <label><div>Mapping Name</div><input value={mappingTitle} onChange={(e)=>setMappingTitle(e.target.value)}/></label>
        <label style={{display:'grid', gridTemplateColumns:'1fr auto', gap:8}}>
          <div><div>Version</div><input value={version} onChange={(e)=>setVersion(e.target.value)}/></div>
          <button onClick={bumpVersion}>+1</button>
        </label>
        <button onClick={save}>Save graph</button>
        <button onClick={saveThenPreview}>Save → Preview</button>
        <button onClick={download}>Download</button>
        <button onClick={clear}>Clear Canvas</button>
      </div>
    </div>
    <div className='canvas'>
      <Canvas nodes={nodes} edges={edges} setEdges={setEdges} onSelect={onSelect} onNodesChange={onNodesChange} onEdgesChange={onEdgesChange} onCreateNode={onCreateNode}/>
    </div>
    <div className='rightbar'>
      <TogglePanel title='Inspector' visible={showInspector} onToggle={()=>setShowInspector(!showInspector)}>
        <Inspector selectedNode={selectedNode} setSelectedNode={setSelectedNode} selectedEdge={selectedEdge} setEdges={setEdges} setNodes={setNodes}/>
      </TogglePanel>
      <TogglePanel title='Attribute Mapping' visible={showAttributes} onToggle={()=>setShowAttributes(!showAttributes)}>
        <AttributeGrid rows={attrs} setRows={(fn:any)=> setAttrs(typeof fn==='function'? fn(attrs):fn)}/>
      </TogglePanel>
      <LegendPanel/>
    </div>
  </div>)
}
