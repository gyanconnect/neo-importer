import React, {useState} from 'react'
import { listProfiles, upsertProfile, saveProfiles } from '../profiles'
export default function SettingsPage(){
  const [apiBase,setApiBase] = useState(localStorage.getItem('apiBase') || 'http://localhost:8000')
  const [items,setItems] = useState(listProfiles())
  const add=()=>{ const id='p'+(Math.random()*1e6|0); setItems([...items,{id,name:'New',kind:'NEO4J',params:{}} as any]) }
  const saveAll=()=>{ localStorage.setItem('apiBase', apiBase); saveProfiles(items); alert('Saved') }
  return <div style={{padding:12, display:'grid', gap:12}}>
    <div className="panel"><label>API Base <input value={apiBase} onChange={e=>setApiBase(e.target.value)} style={{width:'100%'}}/></label></div>
    <div className="panel">
      <div style={{marginBottom:8}}><strong>Connection Profiles</strong></div>
      {items.map((p,i)=> (
        <div key={p.id} style={{display:'grid', gridTemplateColumns:'1fr 120px 1fr', gap:8, marginBottom:8}}>
          <input value={p.name} onChange={e=> setItems(items.map((x,xi)=> xi===i? {...x,name:e.target.value}:x))}/>
          <select value={p.kind} onChange={e=> setItems(items.map((x,xi)=> xi===i? {...x,kind:e.target.value}:x))}>
            {['HIVE','NEO4J','MONGO','ORACLE','FILE','KAFKA','API','GQL','ELASTIC'].map(k=> <option key={k} value={k}>{k}</option>)}
          </select>
          <input placeholder="params as JSON" value={JSON.stringify(p.params||{})} onChange={e=> {
            try{ const v=JSON.parse(e.target.value||'{}'); setItems(items.map((x,xi)=> xi===i? {...x,params:v}:x)) } catch {}
          }}/>
        </div>
      ))}
      <div style={{display:'flex', gap:8}}><button onClick={add}>Add Profile</button><button onClick={saveAll}>Save</button></div>
    </div>
  </div>
}
