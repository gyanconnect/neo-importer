import React, { useEffect, useState } from 'react'
import { gql } from '../api/client'

export default function ResultPage(){
  const last = JSON.parse(localStorage.getItem('lastMapping')||'{}')
  const [id,setId] = useState(last.id || 'customer-etl')
  const [version,setVersion] = useState(last.version || 'v1')
  const [title,setTitle] = useState<string>(last.title || '')
  const [jobId,setJobId] = useState(localStorage.getItem('lastJobId')||'')
  const [rows,setRows] = useState<any[][]>([])
  const [cols,setCols] = useState<string[]>([])
  const [error,setError] = useState<string|undefined>()

  useEffect(()=>{
    (async()=>{
      try{
        const data = await gql<any>(`query($id:String!,$v:String!){ mapping(id:$id,version:$v){ title } }`, {id, v:version})
        if(data?.mapping?.title){ setTitle(data.mapping.title); localStorage.setItem('lastMapping', JSON.stringify({id, version, title:data.mapping.title, at: Date.now()})) }
      }catch{}
    })()
  },[id,version])

  async function fetchResult(){
    setError(undefined)
    try{
      const q = `query($job:String!){ exec_result(jobId:$job){ columns rows } }`
      const data = await gql<any>(q, {job: jobId})
      setCols(data.exec_result.columns); setRows(data.exec_result.rows)
    }catch(e:any){ setError(e.message||String(e)) }
  }

  return <div style={{padding:12, display:'grid', gap:12}}>
    <div className="panel" style={{display:'flex', gap:12, alignItems:'center'}}>
      <strong>Result {title ? `— ${title}` : ''}</strong>
      <label>Job ID <input value={jobId} onChange={e=>setJobId(e.target.value)} /></label>
      <button onClick={fetchResult} disabled={!jobId}>Fetch Result</button>
    </div>
    {error && <div className="panel" style={{borderColor:'tomato', color:'tomato'}}>Error: {error}</div>}
    <div className="panel" style={{overflow:'auto'}}>
      <table style={{width:'100%', fontSize:13}}>
        <thead><tr>{cols.map(c=> <th key={c} style={{textAlign:'left', padding:6}}>{c}</th>)}</tr></thead>
        <tbody>
          {rows.map((r,i)=> <tr key={i}>{r.map((v,j)=> <td key={j} style={{padding:6, borderTop:'1px solid var(--border)'}}>{String(v)}</td>)}</tr>)}
          {rows.length===0 && <tr><td style={{padding:8, opacity:.7}}>No data</td></tr>}
        </tbody>
      </table>
    </div>
  </div>
}
