
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from strawberry.fastapi import GraphQLRouter
from config import settings
from graph.schema import schema

from routers.profiles import router as profiles_router
from routers.mappings import router as mappings_router
from routers.exec import router as exec_router
from routers.codegen import router as codegen_router

app = FastAPI(title=settings.API_TITLE, version=settings.API_VERSION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

graphql_app = GraphQLRouter(schema, graphiql=True)
app.include_router(graphql_app, prefix="/graphql")
app.include_router(profiles_router)
app.include_router(mappings_router)
app.include_router(exec_router)
app.include_router(codegen_router)

@app.get("/api/health", tags=["meta"])
def health():
    return {"ok": True, "version": settings.API_VERSION}
