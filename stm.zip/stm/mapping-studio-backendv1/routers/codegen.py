
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from typing import Dict, Any
import io, zipfile, json

router = APIRouter(prefix="/code", tags=["codegen"])

def airflow_dag(mapping: Dict[str, Any]) -> str:
    dag_id = f"ms_{mapping['id']}_{mapping['version']}".replace('-', '_')
    return f"""from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

with DAG('{dag_id}', start_date=datetime(2024,1,1), schedule=None, catchup=False) as dag:
    validate = BashOperator(task_id='validate', bash_command='echo validate')
    plan = BashOperator(task_id='plan', bash_command='echo plan')
    preview = BashOperator(task_id='preview', bash_command='echo preview')
    run = BashOperator(task_id='run', bash_command='echo run')
    validate >> plan >> preview >> run
"""

def ca7_jil(mapping: Dict[str, Any]) -> str:
    base = f"MS_{mapping['id']}_{mapping['version']}".upper().replace('-', '_')
    steps = ["VALIDATE","PLAN","PREVIEW","RUN"]
    out = []
    prev=None
    for step in steps:
        name=f"{base}_{step}"
        jil = f"insert_job: {name}  job_type: CMD\ncommand: echo {step.lower()}\nowner: user\npermission: gx,ge\ndescription: \"{mapping.get('title') or mapping['id']} - {step}\"\n"
        if prev: jil += f"condition: {prev}\n"
        out.append(jil)
        prev=name
    return "\n".join(out)

def sh_script(mapping: Dict[str, Any]) -> str:
    return f"""#!/usr/bin/env bash
set -euo pipefail
echo "Validate {mapping['id']}"
echo "Plan {mapping['id']}"
echo "Preview {mapping['id']}"
echo "Run {mapping['id']}"
"""

def bat_script(mapping: Dict[str, Any]) -> str:
    return f"""@echo off
echo Validate {mapping['id']}
echo Plan {mapping['id']}
echo Preview {mapping['id']}
echo Run {mapping['id']}
"""

@router.post("/bundle.zip")
def code_bundle(mapping: Dict[str, Any]):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("airflow/dag.py", airflow_dag(mapping))
        z.writestr("ca7/flow.jil", ca7_jil(mapping))
        z.writestr("scripts/execute.sh", sh_script(mapping))
        z.writestr("scripts/execute.bat", bat_script(mapping))
        z.writestr("mapping.json", json.dumps(mapping, indent=2))
    buf.seek(0)
    fname = f"codegen_{mapping.get('id','mapping')}_{mapping.get('version','v1')}.zip"
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": f"attachment; filename={fname}"})
