
from fastapi import APIRouter, HTTPException
from typing import List
from models.profile import Profile
from repositories.repo import Repo

router = APIRouter(prefix="/api/profiles", tags=["profiles"])
repo = Repo()

@router.get("", response_model=List[Profile])
def list_profiles(): return repo.list_profiles()

@router.get("/{id}", response_model=Profile)
def get_profile(id: str):
    p = repo.get_profile(id)
    if not p: raise HTTPException(404, "Not found")
    return p

@router.post("", response_model=Profile)
def create_profile(p: Profile):
    if repo.get_profile(p.id): raise HTTPException(409, "Profile exists")
    return repo.upsert_profile(p.model_dump())

@router.put("/{id}", response_model=Profile)
def update_profile(id: str, p: Profile):
    if id != p.id: raise HTTPException(400, "ID mismatch")
    return repo.upsert_profile(p.model_dump())

@router.delete("/{id}")
def delete_profile(id: str): return {"ok": repo.delete_profile(id)}
