
from fastapi import APIRouter, HTTPException
from models.mapping import MappingPayload, UiPayload
from repositories.repo import Repo

router = APIRouter(prefix="/api", tags=["mappings"])
repo = Repo()

@router.post("/mappings")
def upsert_mapping(payload: MappingPayload):
    ok = repo.upsert_mapping(payload.model_dump())
    if ok != "OK": raise HTTPException(500, "Failed to persist")
    return {"ok": True}

@router.get("/mappings/{id}/{version}")
def get_mapping(id: str, version: str):
    m = repo.get_mapping(id, version)
    if not m: raise HTTPException(404, "Not found")
    return m

@router.post("/ui/{id}/{version}")
def set_ui(id: str, version: str, ui: UiPayload):
    return {"ok": repo.set_ui(id, version, ui.model_dump())}

@router.get("/ui/{id}/{version}")
def get_ui(id: str, version: str):
    ui = repo.get_ui(id, version)
    if not ui: raise HTTPException(404, "Not found")
    return ui
