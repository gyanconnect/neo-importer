
from fastapi import APIRouter
from repositories.repo import Repo
from exec_engine.engine import start_job, status, logs, result

router = APIRouter(prefix="/exec", tags=["exec"])
repo = Repo()

@router.post("/validate")
def exec_validate(id: str, version: str): return repo.get_mapping(id, version) is not None

@router.post("/plan")
def exec_plan(id: str, version: str): return {"plan":"READ source → TRANSFORM → WRITE target"}

@router.post("/preview")
def exec_preview(id: str, version: str):
    m = repo.get_mapping(id, version) or {}
    cols = [a.get("targetAttr","") for a in (m.get("attributes") or [])][:6] or ["col1","col2"]
    sample = [[f"r{i}c{j}" for j in range(len(cols))] for i in range(3)]
    return {"columns": cols, "sampleRows": sample}

@router.post("/run")
def exec_run(id: str, version: str):
    m = repo.get_mapping(id, version) or {"id":id,"version":version}
    return {"jobId": start_job(m)}

@router.get("/status/{job_id}")
def exec_status(job_id: str): return {"status": status(job_id)}

@router.get("/logs/{job_id}")
def exec_logs(job_id: str): return {"logs": logs(job_id)}

@router.get("/result/{job_id}")
def exec_result(job_id: str): return result(job_id)
