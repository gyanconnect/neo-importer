
from typing import Any, Dict, List, Optional
from neo4j_conn import get_driver, is_available

class Repo:
    def __init__(self):
        self.mem = { "mappings":{}, "ui":{}, "profiles":{} }

    # Mapping
    def upsert_mapping(self, m: Dict[str, Any]) -> str:
        key=(m["id"], m["version"])
        self.mem["mappings"][key] = m
        if is_available():
            drv = get_driver()
            with drv.session() as s:
                s.run("""MERGE (m:Mapping {id:$id, version:$v})
SET m.title=$title, m.description=$desc, m.status=$status, m.attributes_json=$attrs
""", {
    "id": m["id"], "v": m["version"], "title": m.get("title"),
    "desc": m.get("description"), "status": m.get("status"),
    "attrs": str(m.get("attributes") or [])
}).consume()
        return "OK"

    def get_mapping(self, id:str, version:str)->Optional[Dict[str,Any]]:
        key=(id,version)
        if key in self.mem["mappings"]:
            return self.mem["mappings"][key]
        if is_available():
            drv = get_driver()
            with drv.session() as s:
                rec = s.run("MATCH (m:Mapping {id:$id, version:$v}) RETURN m LIMIT 1",
                            {"id":id,"v":version}).single()
                if rec:
                    node = rec["m"]
                    return {
                        "id": node.get("id"), "version": node.get("version"),
                        "title": node.get("title"), "description": node.get("description"),
                        "status": node.get("status"),
                        "source": {"id":"", "kind":"", "name":""},
                        "target": {"id":"", "kind":"", "name":""},
                        "attributes": []
                    }
        return None

    # UI
    def set_ui(self, id: str, version: str, ui: Dict[str, Any]) -> bool:
        self.mem["ui"][(id,version)] = ui
        if is_available():
            drv = get_driver()
            with drv.session() as s:
                s.run("""MERGE (u:UI {id:$id, version:$v})
SET u.json=$json
""", {"id":id, "v":version, "json":ui}).consume()
        return True

    def get_ui(self, id:str, version:str)->Optional[Dict[str,Any]]:
        if (id,version) in self.mem["ui"]:
            return self.mem["ui"][(id,version)]
        if is_available():
            drv = get_driver()
            with drv.session() as s:
                rec = s.run("MATCH (u:UI {id:$id, version:$v}) RETURN u LIMIT 1",
                            {"id":id,"v":version}).single()
                if rec:
                    return rec["u"].get("json")
        return None

    # Profiles
    def list_profiles(self)->List[Dict[str,Any]]:
        if is_available():
            drv=get_driver()
            with drv.session() as s:
                rows=s.run("MATCH (p:Profile) RETURN p").data()
                if rows: return [dict(r["p"]) for r in rows]
        return list(self.mem["profiles"].values())

    def get_profile(self, id:str)->Optional[Dict[str,Any]]:
        if is_available():
            drv=get_driver()
            with drv.session() as s:
                row=s.run("MATCH (p:Profile {id:$id}) RETURN p",{"id":id}).single()
                if row: return dict(row["p"])
        return self.mem["profiles"].get(id)

    def upsert_profile(self, p:Dict[str,Any])->Dict[str,Any]:
        self.mem["profiles"][p["id"]] = p
        if is_available():
            drv=get_driver()
            with drv.session() as s:
                s.run("MERGE (p:Profile {id:$id}) SET p.name=$name, p.kind=$kind, p.params=$params", p).consume()
        return p

    def delete_profile(self, id:str)->bool:
        self.mem["profiles"].pop(id, None)
        if is_available():
            drv=get_driver()
            with drv.session() as s:
                s.run("MATCH (p:Profile {id:$id}) DETACH DELETE p", {"id":id}).consume()
        return True
