
from neo4j import GraphDatabase, basic_auth
from config import settings

_driver = None
_available = False

def get_driver():
    global _driver, _available
    if _driver:
        return _driver
    try:
        _driver = GraphDatabase.driver(settings.NEO4J_URI, auth=basic_auth(settings.NEO4J_USER, settings.NEO4J_PASSWORD))
        with _driver.session() as s:
            s.run("RETURN 1").consume()
        _available = True
    except Exception:
        _driver = None
        _available = False
    return _driver

def is_available() -> bool:
    get_driver()
    return _available
