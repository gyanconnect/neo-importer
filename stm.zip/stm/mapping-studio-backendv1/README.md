
# Mapping Studio Backend (Full)
- GraphQL at `/graphql`
- REST for mappings/UI, profiles, exec, codegen
- Neo4j persistence with in-memory fallback
- Swagger at `/docs`

## Run
```
python -m venv .venv && . .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app:app --reload --port 8000
```
