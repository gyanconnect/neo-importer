
from repositories.repo import Repo

class ProfileStore:
    _instance = None

    def __init__(self):
        self.repo = Repo()

    @classmethod
    def get(cls):
        if not cls._instance:
            cls._instance = ProfileStore()
        return cls._instance

    # thin proxies
    def list(self): return self.repo.list_profiles()
    def get_one(self, id:str): return self.repo.get_profile(id)
    def upsert(self, p:dict): return self.repo.upsert_profile(p)
    def delete(self, id:str): return self.repo.delete_profile(id)
