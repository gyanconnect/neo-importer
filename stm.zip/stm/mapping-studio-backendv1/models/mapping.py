
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class NodeInput(BaseModel):
    id: str = Field(..., max_length=128)
    kind: Optional[str] = None
    name: Optional[str] = None
    config: Optional[Dict[str, Any]] = None

class AttributeInput(BaseModel):
    sourceAttr: str
    targetAttr: str
    expression: Optional[str] = ""
    filter: Optional[str] = ""
    alias: Optional[str] = ""
    dtype: Optional[str] = ""

class MappingPayload(BaseModel):
    id: str
    version: str
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    source: NodeInput
    target: NodeInput
    attributes: List[AttributeInput] = []

class UiPayload(BaseModel):
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]
