
from pydantic import BaseModel, Field
from typing import Dict

class Profile(BaseModel):
    id: str = Field(..., max_length=128)
    name: str = Field(..., max_length=128)
    kind: str = Field(..., max_length=64)  # HIVE|NEO4J|MONGO|ORACLE|FILE|KAFKA|API|GQL|ELASTIC
    params: Dict[str, str] = {}
