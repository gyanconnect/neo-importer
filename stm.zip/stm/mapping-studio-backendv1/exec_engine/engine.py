
import time, uuid
from typing import Dict, Any, List

_jobs: Dict[str, Dict[str, Any]] = {}

def start_job(mapping: Dict[str, Any]) -> str:
    j = str(uuid.uuid4())[:8]
    _jobs[j] = {
        "status":"RUNNING",
        "start": time.time(),
        "logs": ["job started"],
        "result": {
            "columns":["customer_key","full_name","email","age_years"],
            "rows":[["C001","Ada Lovelace","ada@ex.com","36"],["C002","Alan Turing","alan@ex.com","41"]]
        }
    }
    return j

def status(job_id: str) -> str:
    j = _jobs.get(job_id)
    if not j: return "NOT_FOUND"
    if j["status"] == "RUNNING" and (time.time()-j["start"]>2):
        j["status"]="SUCCEEDED"; j["logs"].append("completed")
    return j["status"]

def logs(job_id: str) -> List[str]:
    j=_jobs.get(job_id); return j["logs"] if j else []

def result(job_id: str):
    j=_jobs.get(job_id); return j["result"] if j else {"columns":[],"rows":[]}
