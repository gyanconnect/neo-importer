
import strawberry
from typing import List, Optional
from strawberry.scalars import JSON


@strawberry.type
class Mapping:
    id: str
    version: str
    title: Optional[str]
    description: Optional[str]
    status: Optional[str]
    source: JSON
    target: JSON
    attributes: List[JSON]

@strawberry.input
class NodeInput:
    id: str
    kind: Optional[str] = None
    name: Optional[str] = None
    config: Optional[JSON] = None

@strawberry.input
class AttributeInput:
    sourceAttr: str
    targetAttr: str
    expression: Optional[str] = None
    filter: Optional[str] = None
    alias: Optional[str] = None
    dtype: Optional[str] = None

@strawberry.input
class MappingInput:
    id: str
    version: str
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    source: NodeInput
    target: NodeInput
    attributes: List[AttributeInput]

@strawberry.type
class Graph:
    nodes: List[JSON]
    edges: List[JSON]
