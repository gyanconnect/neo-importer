
import strawberry
from typing import Optional, List
from .types import Mapping, MappingInput, JSON, Graph
from .repo import GraphRepo
from .exec_schema import ExecQuery, ExecMutation

_repo = GraphRepo()

@strawberry.type
class PreviewResponse:
    sourceLabel: str
    targetLabel: str
    relType: str
    graph: Graph
    sourceSamples: List[JSON]
    targetSamples: List[JSON]

@strawberry.type
class Query(ExecQuery):
    @strawberry.field
    def mapping(self, id: str, version: str) -> Optional[Mapping]:
        m = _repo.get_mapping(id, version)
        if not m: return None
        return Mapping(id=m['id'], version=m['version'], title=m.get('title'), description=m.get('description'),
                       status=m.get('status'), source=m.get('source'), target=m.get('target'), attributes=m.get('attributes', []))
    @strawberry.field
    def ui(self, id: str, version: str) -> Optional[JSON]:
        return _repo.get_ui(id, version)
    @strawberry.field
    def preview_by_mapping(self, id: str, version: str, rel_type: Optional[str] = None, limit: int = 50) -> PreviewResponse:
        p = _repo.preview_by_mapping(id, version, rel_type, limit)
        return PreviewResponse(sourceLabel=p['sourceLabel'], targetLabel=p['targetLabel'], relType=p['relType'],
                               graph=Graph(nodes=p['graph']['nodes'], edges=p['graph']['edges']),
                               sourceSamples=p['sourceSamples'], targetSamples=p['targetSamples'])

@strawberry.type
class Mutation(ExecMutation):
    @strawberry.mutation
    def upsert_mapping(self, input: MappingInput) -> str:
        m = {'id':input.id,'version':input.version,'title':input.title,'description':input.description,'status':input.status,
             'source': input.source.__dict__, 'target': input.target.__dict__, 'attributes':[a.__dict__ for a in input.attributes]}
        return _repo.upsert_mapping(m)
    @strawberry.mutation
    def set_ui(self, id: str, version: str, ui: JSON) -> bool:
        return _repo.set_ui(id, version, ui)

schema = strawberry.Schema(query=Query, mutation=Mutation)
