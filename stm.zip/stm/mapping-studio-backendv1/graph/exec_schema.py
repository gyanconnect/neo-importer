
import strawberry
from typing import List
from .repo import GraphRepo
from exec_engine.engine import start_job, status as job_status, logs as job_logs, result as job_result

_repo = GraphRepo()

@strawberry.type
class PreviewGrid:
    columns: List[str]
    sampleRows: List[List[str]]

@strawberry.type
class ResultGrid:
    columns: List[str]
    rows: List[List[str]]

@strawberry.type
class ExecQuery:
    @strawberry.field
    def exec_validate(self, id: str, version: str) -> bool:
        return _repo.get_mapping(id, version) is not None
    @strawberry.field
    def exec_plan(self, id: str, version: str) -> str:
        return 'Plan: READ source → TRANSFORM → WRITE target'
    @strawberry.field
    def exec_preview(self, id: str, version: str) -> PreviewGrid:
        m = _repo.get_mapping(id, version)
        cols = [a.get('targetAttr','') for a in (m.get('attributes') if m else [])][:6] or ['col1','col2']
        sample = [[f"r{i}c{j}" for j in range(len(cols))] for i in range(3)]
        return PreviewGrid(columns=cols, sampleRows=sample)
    @strawberry.field
    def exec_status(self, job_id: str) -> str:
        return job_status(job_id)
    @strawberry.field
    def exec_logs(self, job_id: str) -> List[str]:
        return job_logs(job_id)
    @strawberry.field
    def exec_result(self, job_id: str) -> ResultGrid:
        r = job_result(job_id)
        return ResultGrid(columns=r['columns'], rows=r['rows'])

@strawberry.type
class ExecMutation:
    @strawberry.mutation
    def exec_run(self, id: str, version: str) -> str:
        m = _repo.get_mapping(id, version) or {"id":id, "version":version}
        return start_job(m)
