
from typing import Any, Dict, Optional
from repositories.repo import Repo

class GraphRepo:
    def __init__(self):
        self.repo = Repo()
    def upsert_mapping(self, m: Dict[str, Any]) -> str:
        return self.repo.upsert_mapping(m)
    def get_mapping(self, id:str, version:str):
        return self.repo.get_mapping(id, version)
    def set_ui(self, id:str, version:str, ui:Dict[str,Any])->bool:
        return self.repo.set_ui(id, version, ui)
    def get_ui(self, id:str, version:str):
        return self.repo.get_ui(id, version)
    def preview_by_mapping(self, id:str, version:str, rel_type:str|None, limit:int):
        m = self.repo.get_mapping(id, version) or {}
        src_label = (m.get('source') or {}).get('name') or 'Source'
        tgt_label = (m.get('target') or {}).get('name') or 'Target'
        graph = {'nodes':[{'id':'s1','label':src_label,'caption':'sample src'},{'id':'t1','label':tgt_label,'caption':'sample tgt'}],
                 'edges':[{'id':'e1','source':'s1','target':'t1','type':rel_type or 'MAPS_TO','attrs':{}}]}
        return {'sourceLabel':src_label,'targetLabel':tgt_label,'relType':rel_type or 'MAPS_TO',
                'graph':graph,
                'sourceSamples':[{'props':{'id':'S1','name':'Alice'}}],
                'targetSamples':[{'props':{'id':'T1','name':'Alice Clean'}}]}
