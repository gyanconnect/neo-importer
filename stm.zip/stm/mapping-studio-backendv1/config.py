from pydantic_settings import BaseSettings
from pydantic import field_validator
from typing import List, Any

class Settings(BaseSettings):
    NEO4J_URI: str = "bolt://localhost:7687"
    NEO4J_USER: str = "neo4j"
    NEO4J_PASSWORD: str = "neoadmin"

    # Accept JSON array OR comma-separated string
    ALLOWED_ORIGINS: List[str] = ["http://localhost:5173", "http://127.0.0.1:5173"]

    API_TITLE: str = "Mapping Studio Backend"
    API_VERSION: str = "3.9.7"

    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def _coerce_origins(cls, v: Any):
        if isinstance(v, str):
            # allow comma-separated env style
            parts = [s.strip() for s in v.split(",") if s.strip()]
            if parts:
                return parts
        return v

    class Config:
        env_file = ".env"

settings = Settings()
