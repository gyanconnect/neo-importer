
import Papa from 'papaparse';
import * as XLSX from 'xlsx';

export async function parseCsv(file: File){
  return new Promise<{headers:string[];rows:any[]}>((resolve,reject)=>{
    Papa.parse(file,{header:true,skipEmptyLines:true,worker:true,
      complete:(res:any)=>{const rows=res.data;const headers=rows.length?Object.keys(rows[0]):[];resolve({headers,rows});},
      error:reject
    });
  });
}

export async function parseJson(file: File){
  const text = await file.text();
  let data:any; try{ data = JSON.parse(text); }catch{ throw new Error('Invalid JSON'); }
  let rows:any[]=[];
  if(Array.isArray(data)) rows=data;
  else if(data && typeof data==='object'){
    const arr = Object.values(data).find((v:any)=>Array.isArray(v));
    if(arr) rows = arr as any[];
  }
  if(!rows.length) throw new Error('JSON should contain an array of objects');
  const sample = rows.slice(0,50);
  const headers = Array.from(new Set(sample.flatMap((r:any)=>Object.keys(r||{}))));
  return {headers,rows};
}

export async function parseExcel(file: File){
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf,{type:'array'});
  const sn = wb.SheetNames[0];
  if(!sn) throw new Error('Workbook has no sheets');
  const ws = wb.Sheets[sn];
  const rows:any[] = XLSX.utils.sheet_to_json(ws,{defval:''});
  const headers = rows.length?Object.keys(rows[0]):[];
  return {headers,rows};
}

export async function parseFile(file: File){
  const name = (file.name||'').toLowerCase();
  const type = (file.type||'').toLowerCase();
  const byExt = (ext:string)=>name.endsWith(ext);
  const isCsv   = byExt('.csv')  || type.includes('text/csv');
  const isJson  = byExt('.json') || type.includes('application/json');
  const isExcel = ['.xlsx','.xls'].some(byExt) || type.includes('spreadsheet') || type.includes('excel');
  if(isCsv) return parseCsv(file);
  if(isJson) return parseJson(file);
  if(isExcel) return parseExcel(file);
  try{ return await parseCsv(file); }catch{}
  try{ return await parseJson(file); }catch{}
  throw new Error('Unsupported file type');
}

export async function parseFiles(files: File[]){
  const outputs = await Promise.all(files.map(async f=>{
    const {headers,rows} = await parseFile(f);
    const sample = rows.slice(0,10); // 10-row sample for preview
    const tagged = rows.map((r:any)=>({...r,_source:f.name}));
    return {file:f.name,headers,rows:tagged,sample};
  }));
  const set=new Set(['_source']);
  outputs.forEach(o=>o.headers.forEach((h:string)=>set.add(h)));
  const headers = Array.from(set);
  const rows:any[]=[];
  for(const o of outputs){
    for(const r of o.rows){
      const row:any={};
      headers.forEach(h=>row[h]=(r as any)[h] ?? '');
      rows.push(row);
    }
  }
  const infos = outputs.map(o=>({name:o.file,rows:o.rows.length}));
  const previews = outputs.map(o=>({name:o.file,headers:o.headers,sample:o.sample,rows:o.rows.length}));
  return {headers,rows,infos,previews};
}
