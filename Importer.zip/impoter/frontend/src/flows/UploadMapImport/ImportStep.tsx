
import { useEffect, useMemo, useState } from "react";
import type { MappingConfig, UploadState, ImportOptions, ImportResult } from "./types";
import { API } from "../../lib/api";

export default function ImportStep({
  upload, mapping, options, result, onResult, onBack, onReset
}: { upload: UploadState; mapping: MappingConfig; options: ImportOptions; result: ImportResult | null; onResult: (r: ImportResult | null) => void; onBack: () => void; onReset: () => void; }){
  const [running,setRunning]=useState(false);
  const [pct,setPct]=useState(0);
  const [log,setLog]=useState('');

  const rows = upload.allRows || [];
  const total = rows.length;

  async function runImport(){
    setRunning(true); setPct(0); setLog('');
    try{
      // chunk in 5k rows
      const chunkSize = 5000;
      let insN=0, insR=0; const errs:any[]=[];
      for(let i=0;i<rows.length;i+=chunkSize){
        const chunk = rows.slice(i, i+chunkSize);
        const body = JSON.stringify({ mapping, rows: chunk, database: options.database || undefined, createMissingNodes: !!options.createMissingNodes });
        const res = await fetch(`${API}/import`, { method:'POST', headers:{'Content-Type':'application/json'}, body });
        const data = await res.json();
        if(!res.ok){ throw new Error(data?.detail || JSON.stringify(data)); }
        insN += data.insertedNodes || 0; insR += data.insertedRels || 0;
        (data.errors||[]).forEach((e:any)=>errs.push(e));
        setPct(Math.round(((i+chunk.length)/rows.length)*100));
        setLog(l => l + `Imported ${i+chunk.length}/${rows.length}\n`);
      }
      onResult({ insertedNodes: insN, insertedRels: insR, errors: errs });
    }catch(e:any){
      setLog(l => l + `\nERROR: ${e?.message || String(e)}`);
    }finally{
      setRunning(false);
    }
  }

  useEffect(()=>{ setPct(0); },[upload, mapping]);

  return (<section className='card cardish'>
    <h2 className='section-title'>Import</h2>
    <p className='muted'>Database: <b>{options.database || 'neo4j'}</b> · Rows: <b>{total}</b></p>

    <div className='footerbar'>
      <div className='wrap'>
        <div className='label'>Progress</div>
        <div className='progress'><div className='bar' style={{ width: pct + '%' }} /></div>
        <div style={{width:56, textAlign:'right'}} className='small'>{pct}%</div>
        <div style={{flex:0}}>
          <button className='btn' onClick={runImport} disabled={running || total===0}>Import</button>
        </div>
      </div>
    </div>

    <div className='log' aria-live='polite'><pre style={{margin:0,whiteSpace:'pre-wrap'}}>{log}</pre></div>

    {result && (<div className='group'><div><b>Inserted nodes:</b> {result.insertedNodes} · <b>relationships:</b> {result.insertedRels}</div>
      {result.errors?.length>0 && (<ul>{result.errors.slice(0,10).map((e,i)=>(<li key={i} className='small' style={{color:'#ff8b8b'}}>{JSON.stringify(e)}</li>))}</ul>)}
    </div>)}

    <footer className='actions' style={{marginTop:16}}>
      <button className='btn secondary' onClick={onBack}>Back</button>
      <button className='btn secondary' onClick={onReset}>Start over</button>
    </footer>
  </section>);
}
