import { useEffect, useMemo, useState } from 'react';
import type { MappingConfig, ImportOptions } from './types';
import NVLGraph from './NVLGraph';
import BloomView from './BloomView';

type Sel = { kind: 'node'; label: string } | { kind: 'rel'; idx: number };

export default function ModelStep({
  headers,
  mapping,
  options,
  onBack,
  onNext,
}: {
  headers: string[];
  mapping: MappingConfig;
  options: ImportOptions;
  onBack: () => void;
  onNext: () => void;
}) {
  const [tab, setTab] = useState<'model' | 'bloom'>('model');
  const [sel, setSel] = useState<Sel | null>(null);

  const labels = useMemo(() => {
    const s = new Set<string>();
    mapping.nodes.forEach((n) => s.add(n.nodeLabel));
    mapping.relationships.forEach((r) => {
      s.add(r.from.label);
      s.add(r.to.label);
    });
    return Array.from(s);
  }, [mapping]);

  const [colors, setColors] = useState<Record<string, string>>({});

  useEffect(() => {
    setColors((prev) => {
      const next = { ...prev } as Record<string, string>;
      labels.forEach((l) => {
        if (!next[l]) next[l] = '#f39ab8';
      });
      return next;
    });
  }, [labels]);

  const rels = mapping.relationships;

  const nodeQuery = (lab: string) => `MATCH (n:\`${lab}\`) RETURN n LIMIT 25;`;
  const relQuery = (i: number) => {
    const r = rels[i];
    return `MATCH (a:\`${r.from.label}\`)-[r:\`${r.type}\`]->(b:\`${r.to.label}\`) RETURN a,r,b LIMIT 25;`;
  };

  return (
    <section className="card cardish">
      <h2 className="section-title">Model Preview</h2>
      <p className="muted">
        Switch between model view and a Bloom-like search (each limited to 25 results).
      </p>

      <div className="props" style={{ marginBottom: 12 }}>
        <button
          className={'chip ' + (tab === 'model' ? 'selected' : '')}
          onClick={() => setTab('model')}
        >
          Model
        </button>
        <button
          className={'chip ' + (tab === 'bloom' ? 'selected' : '')}
          onClick={() => setTab('bloom')}
        >
          Bloom
        </button>
      </div>

      {tab === 'model' ? (
        <>
          <div className="model">
            <div className="graphpad">
              <NVLGraph mapping={mapping} colors={colors} onSelect={setSel} />
            </div>
            <aside className="details">
              <div className="group" style={{ marginBottom: 12 }}>
                <div style={{ fontWeight: 600, marginBottom: 6 }}>Node colors</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 8 }}>
                  {labels.map((lab) => (
                    <div key={lab} style={{ display: 'contents' }}>
                      <div>
                        <span className="badge">{lab}</span>
                      </div>
                      <input
                        type="color"
                        value={colors[lab] || '#f39ab8'}
                        onChange={(e) =>
                          setColors((c) => ({ ...c, [lab]: e.target.value }))
                        }
                      />
                    </div>
                  ))}
                </div>
              </div>

              {!sel && (
                <div>
                  <h3>Details</h3>
                  <p className="muted">Select a node or edge to view query.</p>
                </div>
              )}
              {sel?.kind === 'node' && (
                <div>
                  <h3>Node: {sel.label}</h3>
                  <pre className="cypher">{nodeQuery(sel.label)}</pre>
                </div>
              )}
              {sel?.kind === 'rel' && (
                <div>
                  <h3>Relationship: {rels[sel.idx].type}</h3>
                  <pre className="cypher">{relQuery(sel.idx)}</pre>
                </div>
              )}
            </aside>
          </div>
        </>
      ) : (
        <BloomView options={options} mapping={mapping} />
      )}

      <footer className="actions" style={{ marginTop: 16 }}>
        <button className="btn secondary" onClick={onBack}>
          Back
        </button>
        <button
          className="btn"
          onClick={onNext}
          disabled={mapping.nodes.length === 0}
        >
          Next: Import
        </button>
      </footer>
    </section>
  );
}
