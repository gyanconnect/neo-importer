
import { useRef, useState } from "react";
import { parseFile, parseFiles } from "../../lib/csv";
import type { UploadState } from "./types";

export default function UploadStep({
  value, onChange, onNext
}: { value: UploadState; onChange:(u:UploadState)=>void; onNext:()=>void; }){
  const [error,setError]=useState<string|null>(null);
  const [drag,setDrag]=useState(false);
  const inputRef=useRef<HTMLInputElement>(null);

  async function rebuildFromFiles(files: File[]){
    if(files.length===0){
      onChange({ files:[], fileInfos:[], filePreviews:[], headers:[], allRows:[], sample:[] });
      return;
    }
    if(files.length===1){
      const f=files[0];
      const {headers,rows}=await parseFile(f);
      onChange({
        files:[f],
        fileInfos:[{name:f.name, rows:rows.length}],
        filePreviews:[{name:f.name, headers, sample: rows.slice(0,10), rows: rows.length}],
        headers,
        allRows: rows,
        sample: rows.slice(0,10)
      });
    } else {
      const {headers,rows,infos,previews}=await parseFiles(files);
      onChange({
        files, fileInfos: infos, filePreviews: previews,
        headers, allRows: rows, sample: rows.slice(0,10)
      });
    }
  }

  async function handleFiles(list?: FileList | File[]){
    setError(null);
    const files=list?Array.from(list):[];
    if(!files.length) return;
    try{ await rebuildFromFiles(files); }
    catch(e:any){ setError(e?.message ?? 'Failed to parse files'); }
  }

  async function removeFile(idx:number){
    const next=(value.files||[]).filter((_,i)=>i!==idx);
    try{ await rebuildFromFiles(next); }
    catch(e:any){ setError(e?.message ?? 'Failed to update file list'); }
  }

  function onDrop(e:React.DragEvent<HTMLDivElement>){
    e.preventDefault(); setDrag(false);
    const fl=e.dataTransfer.files; if(fl&&fl.length) handleFiles(fl);
  }

  return (<section className='card cardish'>
    <h2 className='section-title'>Upload CSV / JSON / Excel</h2>
    <p className='muted'>Drag & drop one or more files, or click to choose them. We’ll merge headers and preview the first <b>10</b> rows per file.</p>

    <div className={'dropzone '+(drag?'drag':'')} onDragOver={(e)=>{e.preventDefault(); setDrag(true);}}
      onDragLeave={()=>setDrag(false)} onDrop={onDrop} role='button' tabIndex={0} onClick={()=>inputRef.current?.click()}
      onKeyDown={(e)=> (e.key==='Enter'? inputRef.current?.click(): null)} aria-label='Upload files'>
      <div className='center' style={{minHeight:90}}>
        <div><div style={{fontWeight:600, marginBottom:6}}>Drop files here</div><div className='hint'>or click to browse</div></div>
      </div>
      <input ref={inputRef} className='hidden-input' type='file' multiple
        accept='.csv,.json,application/json,.xlsx,.xls,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv'
        onChange={(e)=>handleFiles(e.target.files||undefined)} />
    </div>

    {value.files && value.files.length>0 && (
      <div className='group' style={{marginTop:12}}>
        <div className='small' style={{marginBottom:6}}>Selected files</div>
        <ul className='filelist'>
          {value.files.map((f,i)=>(
            <li key={f.name+i}>
              <span className='badge'>{f.name}</span>
              <button type='button' className='icon-btn danger' title={'Remove '+f.name} aria-label={'Remove '+f.name}
                onClick={(e)=>{e.stopPropagation(); removeFile(i);}}>🗑</button>
            </li>
          ))}
        </ul>
      </div>
    )}

    {value.filePreviews && value.filePreviews.length>0 && (
      <div className='group' style={{marginTop:12}}>
        {value.filePreviews.map(fp=>(
          <div key={fp.name} style={{marginBottom:16}}>
            <div className='small' style={{marginBottom:6}}><strong>{fp.name}</strong> · headers: {fp.headers.length} · showing <b>10</b> of {fp.rows} rows</div>
            <div className='preview'>
              <table><thead><tr>{fp.headers.map(h=><th key={fp.name+h}>{h}</th>)}</tr></thead>
                <tbody>{fp.sample.map((r,i)=>(<tr key={fp.name+i}>{fp.headers.map(h=><td key={fp.name+h}>{(r as any)[h]}</td>)}</tr>))}</tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    )}

    {error&&<p className='small' style={{color:'#ff8b8b'}}>{error}</p>}
    {value.sample.length>0&&(<div className='actions'><button className='btn' onClick={onNext}>Next: Map</button></div>)}
  </section>);
}
