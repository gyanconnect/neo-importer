
import { useEffect, useState } from "react";
import type { MappingConfig, ImportOptions } from "./types";
import { API } from "../../lib/api";

export default function MapStep({
  headers, mapping, options, onOptionsChange, onChange, onBack, onNext
}: { headers:string[]; mapping:MappingConfig; options:ImportOptions; onOptionsChange:(o:ImportOptions)=>void; onChange:(m:MappingConfig)=>void; onBack:()=>void; onNext:()=>void; }){
  const [local,setLocal]=useState<MappingConfig>(mapping||{nodes:[],relationships:[]});
  const [dbs,setDbs]=useState<string[]>([]);

  async function loadDbs(){ try{ const res=await fetch(`${API}/databases`); const data=await res.json(); setDbs(data.databases||[]);
    if(!options.database && data.databases?.length) onOptionsChange({ ...options, database: data.databases[0] }); }catch{} }
  useEffect(()=>{ loadDbs(); },[]);

  function addNode(){ setLocal(m=>({...m, nodes:[...m.nodes, { nodeLabel:'Customer', idColumn: headers[0] ?? '', props:{} }]})); }
  function addRel(){ setLocal(m=>({...m, relationships:[...m.relationships, { type:'HAS_ACCOUNT', from:{label:'Customer',idColumn:headers[0]??''}, to:{label:'Account',idColumn:headers[0]??''}, props:{} }]})); }
  function removeNode(i:number){ setLocal(m=>({...m, nodes: m.nodes.filter((_,idx)=>idx!==i)})); }
  function removeRel(i:number){ setLocal(m=>({...m, relationships: m.relationships.filter((_,idx)=>idx!==i)})); }
  function updateNode(i:number, field:'nodeLabel'|'idColumn', value:string){
    setLocal(m=>{ const nodes=[...m.nodes]; nodes[i]={...nodes[i],[field]:value}; return {...m,nodes}; });
  }

  return (<section className='card cardish'>
    <h2 className='section-title'>Map Columns</h2>
    <p className='muted'>Define how file columns become graph nodes and relationships.</p>

    <div className='group' style={{marginBottom:16}}>
      <div className='row'>
        <label>Target database (used for Import & Bloom)</label>
        <select className='db-select' value={options.database ?? ''}
          onChange={(e)=>onOptionsChange({ ...options, database: e.target.value || undefined })}>
          {dbs.map(db=>(<option key={db} value={db}>{db}</option>))}
        </select>
      </div>
    </div>

    <div className='grid'>
      <div>
        <h3>Nodes</h3>
        <button className='btn secondary' onClick={addNode}>+ Add Node Mapping</button>
        {local.nodes.length===0&&<p className='muted'>No nodes yet.</p>}
        {local.nodes.map((n,i)=>(<div key={i} className='group'>
          <div style={{display:'flex',justifyContent:'space-between',marginBottom:8}}>
            <div className='small' style={{opacity:.7}}>Node #{i+1}</div>
            <button type='button' className='icon-btn danger' title='Remove node mapping' aria-label='Remove node mapping' onClick={()=>removeNode(i)}>🗑</button>
          </div>
          <div className='row'><label>Label</label><input type='text' value={n.nodeLabel} onChange={e=>updateNode(i,'nodeLabel',e.target.value)} /></div>
          <div className='row'><label>ID Column</label><select value={n.idColumn} onChange={e=>updateNode(i,'idColumn',e.target.value)}>{headers.map(h=><option key={h} value={h}>{h}</option>)}</select></div>
          <div className='row'><label>Properties</label><div className='props'>{headers.map(h=>(
            <button key={h} type='button' className={'chip '+(n.props?.[h]?'selected':'')} onClick={()=>{
              setLocal(m=>{ const nodes=[...m.nodes]; const nn={...nodes[i]}; const props={...(nn.props||{})} as Record<string,string>;
                if(props[h]) delete props[h]; else props[h]=h; nodes[i]={...nn, props}; return {...m,nodes}; });
            }}>{h}</button>))}</div></div>
        </div>))}
      </div>

      <div>
        <h3>Relationships</h3>
        <button className='btn secondary' onClick={addRel}>+ Add Relationship Mapping</button>
        {local.relationships.length===0&&<p className='muted'>No relationships yet.</p>}
        {local.relationships.map((r,i)=>(<div key={i} className='group'>
          <div style={{display:'flex',justifyContent:'space-between',marginBottom:8}}>
            <div className='small' style={{opacity:.7}}>Relationship #{i+1}</div>
            <button type='button' className='icon-btn danger' title='Remove relationship mapping' aria-label='Remove relationship mapping' onClick={()=>removeRel(i)}>🗑</button>
          </div>
          <div className='row'><label>Type</label><input type='text' value={r.type} onChange={e=>{
            const v=e.target.value; setLocal(m=>{ const rels=[...m.relationships]; rels[i]={...rels[i], type:v}; return {...m, relationships: rels}; });
          }} /></div>
          <div className='row two'><div><label>From.Label</label><input type='text' value={r.from.label} onChange={e=>{
            const v=e.target.value; setLocal(m=>{ const rels=[...m.relationships]; rels[i]={...rels[i], from:{...rels[i].from, label:v}}; return {...m,relationships:rels}; }); }} /></div>
          <div><label>From.ID Column</label><select value={r.from.idColumn} onChange={e=>{
            const v=e.target.value; setLocal(m=>{ const rels=[...m.relationships]; rels[i]={...m.relationships[i], from:{...m.relationships[i].from, idColumn:v}}; return {...m,relationships:rels}; }); }}>{headers.map(h=><option key={h} value={h}>{h}</option>)}</select></div></div>
          <div className='row two'><div><label>To.Label</label><input type='text' value={r.to.label} onChange={e=>{
            const v=e.target.value; setLocal(m=>{ const rels=[...m.relationships]; rels[i]={...m.relationships[i], to:{...m.relationships[i].to, label:v}}; return {...m,relationships:rels}; }); }} /></div>
          <div><label>To.ID Column</label><select value={r.to.idColumn} onChange={e=>{
            const v=e.target.value; setLocal(m=>{ const rels=[...m.relationships]; rels[i]={...m.relationships[i], to:{...m.relationships[i].to, idColumn:v}}; return {...m,relationships:rels}; }); }}>{headers.map(h=><option key={h} value={h}>{h}</option>)}</select></div></div>
          <div className='row'><label>Relationship Properties</label><div className='props'>{headers.map(h=>(
            <button key={h} type='button' className={'chip '+((r.props&&(r.props as any)[h])?'selected':'')} onClick={()=>{
              setLocal(m=>{ const rels=[...m.relationships]; const props={...(rels[i].props||{})} as Record<string,string>;
                if(props[h]) delete props[h]; else props[h]=h; rels[i]={...rels[i], props}; return {...m, relationships: rels}; });
            }}>{h}</button>))}</div></div>
        </div>))}
      </div>
    </div>

    <footer className='actions'><button className='btn secondary' onClick={onBack}>Back</button>
      <button className='btn' onClick={()=>{ onChange(local); onNext(); }} disabled={local.nodes.length===0}>Next: Model</button>
    </footer>
  </section>);
}
