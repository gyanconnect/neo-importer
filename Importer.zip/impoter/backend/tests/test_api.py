
from fastapi.testclient import TestClient
from app.main import app
import app.neo4j_client as neo4j_client

class FakeResult:
    def __init__(self, rows): self._rows = rows
    def __iter__(self): return iter(self._rows)
    def single(self): return self._rows[0] if self._rows else None

class FakeSession:
    def __init__(self): self.queries = []
    def run(self, cypher: str, **params):
        self.queries.append((cypher, params))
        low = cypher.lower()
        if 'show databases' in low:
            return FakeResult([{'name':'neo4j'},{'name':'analytics'}])
        if 'return count(n) as cnt' in low:
            return FakeResult([{'cnt': len(params.get('batch', []))}])
        if 'return count(r) as cnt' in low:
            return FakeResult([{'cnt': len(params.get('batch', []))}])
        if low.startswith(('match','call','with')) or ' return ' in low:
            return FakeResult([{'n': {'id':'X'}}])
        return FakeResult([])
    def __enter__(self): return self
    def __exit__(self, *exc): return False
    def close(self): pass

def test_databases(monkeypatch):
    monkeypatch.setattr(neo4j_client, 'get_session', lambda *a, **k: FakeSession())
    client = TestClient(app)
    r = client.get('/databases')
    assert r.status_code == 200
    data = r.json()
    assert 'databases' in data and 'neo4j' in data['databases']

def test_import(monkeypatch):
    monkeypatch.setattr(neo4j_client, 'get_session', lambda *a, **k: FakeSession())
    client = TestClient(app)
    payload = {
        'mapping': {
            'nodes': [{'nodeLabel':'Customer','idColumn':'customer_id','props':{'first_name':'first_name'}}],
            'relationships': [{'type':'HAS_ACCOUNT','from':{'label':'Customer','idColumn':'customer_id'},'to':{'label':'Account','idColumn':'account_id'},'props':{'since':'opened_at'}}]
        },
        'rows': [
            {'customer_id':'C00001','first_name':'Ava','account_id':'A000001','opened_at':'2024-01-01'},
            {'customer_id':'C00002','first_name':'Liam','account_id':'A000002','opened_at':'2024-01-02'}
        ],
        'createMissingNodes': True
    }
    r = client.post('/import', json=payload)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data['insertedNodes'], int)
    assert isinstance(data['insertedRels'], int)

def test_run_query(monkeypatch):
    monkeypatch.setattr(neo4j_client, 'get_session', lambda *a, **k: FakeSession())
    client = TestClient(app)
    r = client.post('/run', json={'cypher':'MATCH (n) RETURN n LIMIT 1'})
    assert r.status_code == 200
    data = r.json()
    assert 'rows' in data
