
from typing import Dict, List, Any
from neo4j import Session
from pydantic import BaseModel

class MappingRule(BaseModel):
    nodeLabel: str
    idColumn: str
    props: Dict[str, str] = {}

class RelEndpoint(BaseModel):
    label: str
    idColumn: str

class RelationshipRule(BaseModel):
    type: str
    from_: RelEndpoint
    to: RelEndpoint
    props: Dict[str, str] | None = None

class MappingConfig(BaseModel):
    nodes: List[MappingRule] = []
    relationships: List[RelationshipRule] = []

def _build_node_batch(rule: MappingRule, rows: List[Dict[str, Any]]):
    batch=[]
    for r in rows:
        nid_raw=r.get(rule.idColumn)
        if nid_raw is None:
            continue
        nid=str(nid_raw).strip()
        if not nid:
            continue
        props_map={}
        for prop,col in (rule.props or {}).items():
            props_map[prop]=r.get(col)
        batch.append({'id': nid, 'props': props_map})
    return batch

def _build_rel_batch(rule: RelationshipRule, rows: List[Dict[str, Any]]):
    batch=[]
    for r in rows:
        fid_raw=r.get(rule.from_.idColumn); tid_raw=r.get(rule.to.idColumn)
        if fid_raw is None or tid_raw is None:
            continue
        fid=str(fid_raw).strip(); tid=str(tid_raw).strip()
        if not fid or not tid:
            continue
        props_map={}
        for prop,col in (rule.props or {}).items():
            props_map[prop]=r.get(col)
        batch.append({'from_id': fid, 'to_id': tid, 'props': props_map})
    return batch

def _merge_nodes(session: Session, label: str, batch: List[Dict[str, Any]]) -> int:
    if not batch: return 0
    cypher=f"""UNWIND $batch AS item
    MERGE (n:`{label}` {{id: item.id}})
    SET n += item.props
    RETURN count(n) AS cnt"""
    res=session.run(cypher, batch=batch)
    return res.single()['cnt'] or 0

def _merge_rels(session: Session, from_label: str, rel_type: str, to_label: str, batch: List[Dict[str, Any]]) -> int:
    if not batch: return 0
    cypher=f"""UNWIND $batch AS item
    MATCH (a:`{from_label}` {{id: item.from_id}})
    MATCH (b:`{to_label}` {{id: item.to_id}})
    MERGE (a)-[r:`{rel_type}`]->(b)
    SET r += item.props
    RETURN count(r) AS cnt"""
    res=session.run(cypher, batch=batch)
    return res.single()['cnt'] or 0

def ensure_constraints(session: Session, mapping: MappingConfig):
    for rule in mapping.nodes:
        label=rule.nodeLabel.replace('`','')
        cname=f"uniq_{label.lower()}_id"
        cypher=f"CREATE CONSTRAINT {cname} IF NOT EXISTS FOR (n:`{label}`) REQUIRE n.id IS UNIQUE"
        session.run(cypher)

def ingest_chunk(session: Session, mapping: MappingConfig, rows: List[Dict[str, Any]], create_missing_nodes: bool = False):
    inserted_nodes=0; inserted_rels=0; errors=[]
    for rule in mapping.nodes:
        try:
            inserted_nodes += _merge_nodes(session, rule.nodeLabel, _build_node_batch(rule, rows))
        except Exception as e:
            errors.append({'type':'node','label':rule.nodeLabel,'error':str(e)})
    for rule in mapping.relationships:
        try:
            batch=_build_rel_batch(rule, rows)
            if create_missing_nodes:
                _merge_nodes(session, rule.from_.label, [{'id': b['from_id'], 'props': {}} for b in batch])
                _merge_nodes(session, rule.to.label,   [{'id': b['to_id'],   'props': {}} for b in batch])
            inserted_rels += _merge_rels(session, rule.from_.label, rule.type, rule.to.label, batch)
        except Exception as e:
            errors.append({'type':'relationship','rel':rule.type,'error':str(e)})
    return inserted_nodes, inserted_rels, errors
