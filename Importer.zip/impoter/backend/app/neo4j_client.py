
import os
from neo4j import GraphDatabase, Driver, Session

_DRIVER = None

def get_driver() -> Driver:
    global _DRIVER
    if _DRIVER is None:
        uri = "bolt://localhost:7687"
        user = "neo4j"
        password = "neoadmin"
        _DRIVER = GraphDatabase.driver(uri, auth=(user, password))
    return _DRIVER

def get_session(db_override: str | None = None) -> Session:
    env_db = os.getenv("NEO4J_DATABASE")
    db = db_override or env_db
    driver = get_driver()
    return driver.session(database=db) if db else driver.session()
