
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
from .neo4j_client import get_session
from .ingest import ingest_chunk, ensure_constraints

app = FastAPI(title='CSV → Neo4j Import API')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])

class MappingRule(BaseModel):
    nodeLabel: str
    idColumn: str
    props: Dict[str, str] = Field(default_factory=dict)

class RelEndpoint(BaseModel):
    label: str
    idColumn: str

class RelationshipRule(BaseModel):
    type: str
    from_: RelEndpoint = Field(alias='from')
    to: RelEndpoint
    props: Optional[Dict[str, str]] = None

class MappingConfig(BaseModel):
    nodes: List[MappingRule] = Field(default_factory=list)
    relationships: List[RelationshipRule] = Field(default_factory=list)

class ImportRequest(BaseModel):
    mapping: MappingConfig
    rows: List[Dict[str, Any]]
    database: str | None = None
    createMissingNodes: bool = False

class ImportResponse(BaseModel):
    insertedNodes: int
    insertedRels: int
    errors: List[Dict[str, Any]] = Field(default_factory=list)

@app.get('/health')
def health():
    return {'status':'ok'}

@app.get('/databases')
def list_databases():
  try:
    with get_session() as session:
      res = session.run('SHOW DATABASES')
      names = [r.get('name') for r in res if r.get('name') and r.get('name') != 'system']
      seen=set(); ordered=[x for x in names if not (x in seen or seen.add(x))]
      return {'databases': ordered or ['neo4j']}
  except Exception as e:
    import os as _os
    env_db = _os.getenv('NEO4J_DATABASE')
    return {'databases': [env_db] if env_db else ['neo4j'], 'warning': str(e)}

@app.post('/import', response_model=ImportResponse)
def import_rows(req: ImportRequest):
  if not req.rows: return ImportResponse(insertedNodes=0, insertedRels=0, errors=[])
  try:
    with get_session(req.database) as session:
      ensure_constraints(session, req.mapping)
      nodes_count, rels_count, errors = ingest_chunk(session, req.mapping, req.rows, create_missing_nodes=req.createMissingNodes)
    return ImportResponse(insertedNodes=nodes_count, insertedRels=rels_count, errors=errors)
  except Exception as e:
    raise HTTPException(status_code=500, detail=str(e))

class RunRequest(BaseModel):
  cypher: str
  database: str | None = None
  params: Optional[Dict[str, Any]] = None
  limit: Optional[int] = 25

def _serialize(value):
  try:
    from neo4j.graph import Node, Relationship, Path
    if isinstance(value, Node):
      return {'_type':'node','id': value.element_id, 'labels': list(value.labels), 'properties': dict(value)}
    if isinstance(value, Relationship):
      return {'_type':'relationship','id': value.element_id, 'type': value.type, 'properties': dict(value)}
    if isinstance(value, Path):
      return {'_type':'path','nodes':[ _serialize(n) for n in value.nodes ], 'relationships':[ _serialize(r) for r in value.relationships ]}
  except Exception:
    pass
  if isinstance(value, (list, tuple)):
    return [ _serialize(v) for v in value ]
  if isinstance(value, dict):
    return { k: _serialize(v) for k,v in value.items() }
  return value

@app.post('/run')
def run_cypher(req: RunRequest):
  cy = req.cypher.strip()
  if ' limit ' not in cy.lower() and cy.lower().startswith(('match','call','with')):
    cy += f' LIMIT {req.limit or 25}'
  try:
    with get_session(req.database) as session:
      res = session.run(cy, **(req.params or {}))
      rows = [ { k: _serialize(v) for k,v in r.items() } for r in res ]
      return {'rows': rows, 'count': len(rows)}
  except Exception as e:
    return {'error': str(e), 'rows': [], 'count': 0}
