
# Upload → Map → Model → Import (Neo4j)

A ready-to-run full-stack example to import CSV / JSON / Excel into Neo4j with a 4-step UI:
**Upload → Map → Model → Import**, including an NVL-style model graph and a Bloom-like search (LIMIT 25).

## Features
- Drag-and-drop multiple files (CSV / JSON / Excel). Per-file headers preview (25 rows per file).
- Map stage: node + relationship mappings, relationship properties, **target database selector**.
- Model stage: interactive **NVL** graph + **Bloom view (LIMIT 25)**.
- Import stage: chunked import, progress bar, optional `createMissingNodes`.
- Light/Dark theme and accent color picker.
- Unit tests for frontend (Vitest/RTL) and backend (pytest + FastAPI TestClient).

## Requirements
- **Neo4j 5.x** running locally (default `bolt://localhost:7687`), or set env vars.
- **Node 18+** for frontend, **Python 3.10+** for backend.

## Quick Start

### 1) Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
# Optional: export env vars (or use .env)
# NEO4J_URI=bolt://localhost:7687
# NEO4J_USER=neo4j
# NEO4J_PASSWORD=your_password
# NEO4J_DATABASE=neo4j

uvicorn app.main:app --reload --port 8000
```

**API endpoints**
- `GET /health`
- `GET /databases` — list databases (excludes `system`), returns fallback `neo4j` on error.
- `POST /import` — body: `{ mapping, rows, database?, createMissingNodes? }`
- `POST /run` — body: `{ cypher, database?, params?, limit? }`

### 2) Frontend
```bash
cd frontend
npm i
npm run dev
```
Open `http://localhost:5173`

### 3) Flow
1. **Upload** files (CSV/JSON/Excel). Multiple files are merged with `_source` column.
2. **Map** node/relationship mappings and select a **target database**.
3. **Model** to preview NVL graph or Bloom-style search (LIMIT 25).
4. **Import** to send rows to the API (chunked). Progress shows % and totals.

## Tests

### Frontend
```bash
cd frontend
npm test
```

### Backend
```bash
cd backend
pytest -q
```

## Config
Configure Neo4j via environment variables:
- `NEO4J_URI` (default `bolt://localhost:7687`)
- `NEO4J_USER` (default `neo4j`)
- `NEO4J_PASSWORD` (default `password`)
- `NEO4J_DATABASE` (optional; if not set, the server default database is used)

`/databases` endpoint reads available databases with `SHOW DATABASES` and excludes `system`.

## Notes
- To avoid duplicate nodes, the backend creates a **uniqueness constraint** on `id` for each mapped label (`ensure_constraints`). Nodes use `MERGE (n:Label {id})` then `SET n += props`.
- Relationships use `MERGE (a)-[r:TYPE]->(b)` and `SET r += props`. If `createMissingNodes` is `true`, minimal nodes are created for any missing endpoints.
- Bloom view is a simple helper that compiles phrases like `Customer -[HAS_ACCOUNT]-> Account` into Cypher (LIMIT 25).

## Troubleshooting
- **CSV/JSON/Excel parsing:** if you see `... is not a function`, ensure your browser hot-reloaded the **fixed** `src/lib/csv.ts` (uses `.endsWith(...)` — case sensitive).
- **CORS:** the backend enables permissive CORS for local dev.
- **Neo4j auth:** verify credentials and that the DB name exists if you select a non-default database.

---

MIT License. Built for demo purposes.
