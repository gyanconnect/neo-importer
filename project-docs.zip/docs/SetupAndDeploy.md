# Setup & Deploy

## Prerequisites
- Node 18+, npm
- Python 3.11+
- Neo4j 5.x (local or Aura)

## Environment
Create `.env` for the backend (or system env):
```
NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=your_password
NEO4J_DATABASE=neo4j
```

## Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

## Frontend
```bash
cd frontend
npm i
npm run dev
# Vite on http://localhost:5173
```

## Build/Serve
```bash
npm run build
npm run preview
```

## Deployment Notes
- Behind a reverse proxy, expose only the FastAPI and frontend static site.
- For Neo4j Aura, set `NEO4J_URI=neo4j+s://<host>:7687`.
- Consider **unique NODE KEY** in production for strictness.
