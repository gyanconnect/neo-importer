# Testing

## Backend (pytest)
```bash
cd backend
pytest -q
```
Covers:
- `/databases` list
- `/import` happy path using a fake session
- `/run` serialization of nodes/relationships

## Frontend (Vitest + jsdom)
```bash
cd frontend
npm run test
```
Recommended tests:
- **UploadStep**: renders dropzone; parses CSV/JSON/XLSX; enforces 10-row preview; remove file icon works.
- **MapStep**: add/remove node & relationship; multi-label and composite key selections persist; DB select is compact.
- **ModelStep**: NVLGraph renders nodes/edges; color picker updates; Bloom view assembles LIMIT 25 queries.
- **ImportStep**: progress bar increments; results summary shown; errors surface to the log.
