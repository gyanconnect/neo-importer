# Architecture

## Component Diagram (ASCII)
```
┌─────────────┐           HTTP/JSON            ┌──────────────┐          Bolt
│   Browser   │  ───────────────────────────▶  │  FastAPI API │  ──────────────▶  Neo4j
│  React UI   │  ◀───────────────────────────  │  (Uvicorn)   │  ◀──────────────  (DB)
└─────┬───────┘                                └───────┬──────┘
      │ Upload/Map/Model/Import                        │
      │                                                │
      │                              ┌─────────────────▼─────────────────┐
      │                              │ Ingest module (constraints, MERGE)│
      │                              │ - composite keys (n keys)         │
      │                              │ - multi-label nodes (:A:B)        │
      │                              │ - chunking (5k rows)              │
      │                              └────────────────────────────────────┘
```

## Request Flow
1. **Upload**: UI parses files client-side (Papaparse/XLSX). Nothing is stored server-side.
2. **Map**: User defines nodes + relationships. Supports **labels[]** and **keys[]** (composite key).
3. **Model**: NVLGraph renders the schema; Bloom-like view issues `/run` with a safe LIMIT.
4. **Import**: UI sends chunks to `/import`. Backend ensures constraints, merges nodes then relationships.

## Key Backend Pieces
- `neo4j_client.get_session(database?)` — opens a driver session, optional DB override.
- `ingest.ensure_constraints(mapping)` — creates uniqueness (single or composite).
- `ingest.ingest_chunk(session, mapping, rows, create_missing_nodes)` — builds batches and executes Cypher:
  - Nodes: `MERGE (n:\`L1\`:\`L2\` { \`k1\`: item.key.\`k1\`, ... }) SET n += item.props`
  - Rels:  `MATCH ... MERGE (a)-[r:\`TYPE\`]->(b) SET r += item.props`

## Sequence (Upload → Import)
```
User
 │
 │ 1) choose files
 ▼
React (parse) ──> headers + 10-row samples
 │
 │ 2) map nodes/rels (labels[], keys[])
 ▼
Model (NVLGraph/Bloom) ──> optional /run preview
 │
 │ 3) import (chunks) ──> POST /import
 ▼
FastAPI ─ ensure_constraints → merge nodes → merge relationships
 │
 ▼
Neo4j (constraints + MERGE) → results
```

## Data Contracts
- **MappingNode**: `{ labels: string[], keys: string[], props: Record<string,string> }`  
  Backward compatible with `{ nodeLabel, idColumn }` via normalization.
- **RelEndpoint**: `{ labels: string[], keys: string[] }`
- **MappingRel**: `{ type: string, from: RelEndpoint, to: RelEndpoint, props?: Record<string,string> }`
- **ImportRequest**: `{ mapping, rows, database?: string, createMissingNodes?: boolean }`

## Limits & Defaults
- Model/Bloom queries: LIMIT **25**
- Import chunk size: **5,000** rows
- Preview per file: **10** rows
- Default database: env `NEO4J_DATABASE` or `neo4j`
