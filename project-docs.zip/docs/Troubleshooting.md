# Troubleshooting

- `n.endswith is not a function` → Use JS `String.prototype.endsWith` (capital **W**). Fixed in `src/lib/csv.ts`.
- `Expected "}" but found "{"` → A template literal or JSX expression is malformed; check progress bar styles or stray characters.
- ModelStep error around `{ _...prev }` → Remove stray underscore; use `{ ...prev }`.
- Neo4j auth / TLS issues → verify `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD`. Aura requires `neo4j+s://` and trusted certs.
- Mixed files with different headers → the app unions headers and fills missing cells with empty strings.
- Relationship endpoints missing → enable **Create Missing Nodes** during import to precreate endpoints.
