# CSV / JSON / Excel → Graph Import (Neo4j) — Project Overview

This project provides a **ready‑to‑run full‑stack app** to ingest tabular files into **Neo4j** using a guided flow:
**Upload → Map → Model → Import**. It supports CSV, JSON, and Excel; multiple files; and previews.

## Highlights
- **Frontend**: React + Vite (TypeScript), sleek UI, theme + accent color switcher.
- **Stages**:
  1. **Upload** — drop or browse multiple files; previews show **10 rows** per file; **remove file** icons.
  2. **Map** — build node/relationship mappings; **compact Target Database** selector; remove mapping icons.
  3. **Model** — visual model (NVLGraph) with **color-per-label**, and **Bloom-like search** preview (LIMIT 25).
  4. **Import** — chunked ingest with progress bar, logs, and results.
- **Backend**: FastAPI + Neo4j driver.
- **Neo4j**: Creates **uniqueness constraints**; supports **composite keys** and **multiple labels** per node.
- **API**: `/health`, `/databases`, `/import`, `/run` (safe LIMIT for read queries).
- **Tests**: Unit tests for backend API (pytest) and frontend (Vitest).
- **Sample data**: Customers / Accounts / Transactions; JSON + Excel provided.

## Tech Stack
- **Frontend**: React 18, TypeScript, Vite, Papaparse, xlsx, vis-network.
- **Backend**: FastAPI, Pydantic v2, Neo4j Python Driver.
- **Database**: Neo4j 5.x (Aura or local).
