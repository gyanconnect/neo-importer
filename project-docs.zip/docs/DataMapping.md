# Data Mapping — Composite Keys & Multi-Label Nodes

## Nodes
```json
{
  "labels": ["Customer","Retail"],
  "keys": ["customer_id","email"],
  "props": {
    "first_name": "first_name",
    "last_name": "last_name",
    "active": "active"
  }
}
```
- **labels[]** → becomes `(:Customer:Retail)`
- **keys[]** → used in MERGE pattern; also used to build uniqueness constraints.

## Relationships
```json
{
  "type": "HAS_ACCOUNT",
  "from": { "labels": ["Customer","Retail"], "keys": ["customer_id","email"] },
  "to":   { "labels": ["Account"], "keys": ["account_id"] },
  "props": { "since": "opened_at" }
}
```

## Backward Compatibility
Legacy fields are normalized automatically:
- `nodeLabel` → `labels: [nodeLabel]`
- `idColumn` → `keys: [idColumn]`
- relationship endpoints: `label` / `idColumn` → `labels` / `keys`

## Constraints
- Single key: `REQUIRE x.\`id\` IS UNIQUE`
- Composite keys: `REQUIRE (x.\`k1\`, x.\`k2\`) IS UNIQUE`
- You can switch to **NODE KEY** if you need existence + uniqueness guarantees.
