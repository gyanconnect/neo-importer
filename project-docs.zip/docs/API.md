# REST API

Base URL: `http://localhost:8000` (configurable).

## GET `/health`
Returns `{"status":"ok"}`.

## GET `/databases`
Lists user-accessible databases (excluding `system`).
```json
{ "databases": ["neo4j","analytics"] }
```

## POST `/import`
Body:
```jsonc
{
  "mapping": {
    "nodes": [
      { "labels": ["Customer","Retail"], "keys": ["customer_id","email"], "props": {"first_name":"first_name"} },
      { "labels": ["Account"], "keys": ["account_id"], "props": {"opened_at":"opened_at"} }
    ],
    "relationships": [
      { "type": "HAS_ACCOUNT",
        "from": { "labels": ["Customer","Retail"], "keys": ["customer_id","email"] },
        "to":   { "labels": ["Account"], "keys": ["account_id"] },
        "props": { "since": "opened_at" } }
    ]
  },
  "rows": [ { /* flat row object */ } ],
  "database": "neo4j",
  "createMissingNodes": true
}
```
Response:
```json
{ "insertedNodes": 123, "insertedRels": 456, "errors": [] }
```

## POST `/run`
Run Cypher for **preview only**; a LIMIT is added automatically to `MATCH/WITH/CALL` queries when absent.
```json
{ "cypher": "MATCH (n:Customer) RETURN n", "database": "neo4j", "limit": 25 }
```
Response rows serialize Neo4j values:
```json
{ "rows": [ { "n": { "_type":"node", "labels":["Customer"], "properties":{...} } } ], "count": 1 }
```
